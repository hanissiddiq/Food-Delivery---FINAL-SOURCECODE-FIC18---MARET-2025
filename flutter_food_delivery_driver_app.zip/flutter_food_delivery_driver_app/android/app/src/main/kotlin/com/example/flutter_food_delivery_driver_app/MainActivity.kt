package com.jagoflutter.flutter_food_delivery_driver_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
