import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:flutter_food_delivery_driver_app/core/constants/variables.dart';
import 'package:flutter_food_delivery_driver_app/data/models/response/order_response_model.dart';
import 'package:http/http.dart' as http;

import 'auth_local_datasource.dart';

class OrderRemoteDatasource {
  Future<Either<String, OrderResponseModel>> getOrders() async {
    final authData = await AuthLocalDatasource().getAuthData();
    final header = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${authData.data!.token}',
    };
    final url =
        Uri.parse('${Variables.baseUrl}/api/order/driver/waiting-pickup');
    final response = await http.get(url, headers: header);

    if (response.statusCode == 200) {
      return Right(OrderResponseModel.fromJson(response.body));
    } else {
      return Left(response.body);
    }
  }

  Future<Either<String, String>> updateStatus(int id, String status) async {
    final authData = await AuthLocalDatasource().getAuthData();
    final header = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${authData.data!.token}',
    };
    final url = Uri.parse('${Variables.baseUrl}/api/order/driver/update-status/$id');
    final response = await http.put(
      url,
      headers: header,
      body: jsonEncode(
        {'status': status},
      ),
    );

    print('status: ${status}');
    //print url
    print(url);

    if (response.statusCode == 200) {
      return const Right('Success');
    } else {
      return Left(response.body);
    }
  }
}
