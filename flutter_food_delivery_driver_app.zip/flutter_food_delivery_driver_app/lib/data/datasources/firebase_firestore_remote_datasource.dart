import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseFirestoreRemoteDatasource {
  FirebaseFirestoreRemoteDatasource._init();

  static final FirebaseFirestoreRemoteDatasource instance = FirebaseFirestoreRemoteDatasource._init();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> createOrderTracking({
    required int orderId,
    required String currentLat,
    required String currentLong,
    required String orderStatus,
  })async{
    await _firestore.collection('order_tracking').doc(orderId.toString()).set({
      'orderId': orderId,
      'currentLat': currentLat,
      'currentLong': currentLong,
      'orderStatus': orderStatus,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  Future<void> updateOrderTracking({
    required int orderId,
    required String currentLat,
    required String currentLong,
    required String orderStatus,
  })async{
    await _firestore.collection('order_tracking').doc(orderId.toString()).update({
      'currentLat': currentLat,
      'currentLong': currentLong,
      'orderStatus': orderStatus,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }
}