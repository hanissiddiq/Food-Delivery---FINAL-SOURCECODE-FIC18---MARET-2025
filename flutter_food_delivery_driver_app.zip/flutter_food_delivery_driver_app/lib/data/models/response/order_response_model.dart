import 'dart:convert';

class OrderResponseModel {
    final String? message;
    final List<Order>? orders;

    OrderResponseModel({
        this.message,
        this.orders,
    });

    factory OrderResponseModel.fromJson(String str) => OrderResponseModel.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory OrderResponseModel.fromMap(Map<String, dynamic> json) => OrderResponseModel(
        message: json["message"],
        orders: json["orders"] == null ? [] : List<Order>.from(json["orders"]!.map((x) => Order.fromMap(x))),
    );

    Map<String, dynamic> toMap() => {
        "message": message,
        "orders": orders == null ? [] : List<dynamic>.from(orders!.map((x) => x.toMap())),
    };
}

class Order {
    final int? id;
    final int? userId;
    final int? restaurantId;
    final dynamic driverId;
    final int? totalPrice;
    final int? shippingCost;
    final int? totalBill;
    final String? paymentMethod;
    final String? status;
    final String? shippingAddress;
    final String? shippingLatlong;
    final DateTime? createdAt;
    final DateTime? updatedAt;
    final Restaurant? user;
    final Restaurant? restaurant;

    Order({
        this.id,
        this.userId,
        this.restaurantId,
        this.driverId,
        this.totalPrice,
        this.shippingCost,
        this.totalBill,
        this.paymentMethod,
        this.status,
        this.shippingAddress,
        this.shippingLatlong,
        this.createdAt,
        this.updatedAt,
        this.user,
        this.restaurant,
    });

    factory Order.fromJson(String str) => Order.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory Order.fromMap(Map<String, dynamic> json) => Order(
        id: json["id"],
        userId: json["user_id"],
        restaurantId: json["restaurant_id"],
        driverId: json["driver_id"],
        totalPrice: json["total_price"],
        shippingCost: json["shipping_cost"],
        totalBill: json["total_bill"],
        paymentMethod: json["payment_method"],
        status: json["status"],
        shippingAddress: json["shipping_address"],
        shippingLatlong: json["shipping_latlong"],
        createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
        user: json["user"] == null ? null : Restaurant.fromMap(json["user"]),
        restaurant: json["restaurant"] == null ? null : Restaurant.fromMap(json["restaurant"]),
    );

    Map<String, dynamic> toMap() => {
        "id": id,
        "user_id": userId,
        "restaurant_id": restaurantId,
        "driver_id": driverId,
        "total_price": totalPrice,
        "shipping_cost": shippingCost,
        "total_bill": totalBill,
        "payment_method": paymentMethod,
        "status": status,
        "shipping_address": shippingAddress,
        "shipping_latlong": shippingLatlong,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "user": user?.toMap(),
        "restaurant": restaurant?.toMap(),
    };
}

class Restaurant {
    final int? id;
    final String? name;
    final String? email;
    final dynamic emailVerifiedAt;
    final DateTime? createdAt;
    final DateTime? updatedAt;
    final String? phone;
    final String? address;
    final String? roles;
    final dynamic licensePlate;
    final String? restaurantName;
    final String? restaurantAddress;
    final String? photo;
    final String? latlong;
    final String? fcmId;

    Restaurant({
        this.id,
        this.name,
        this.email,
        this.emailVerifiedAt,
        this.createdAt,
        this.updatedAt,
        this.phone,
        this.address,
        this.roles,
        this.licensePlate,
        this.restaurantName,
        this.restaurantAddress,
        this.photo,
        this.latlong,
        this.fcmId,
    });

    factory Restaurant.fromJson(String str) => Restaurant.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory Restaurant.fromMap(Map<String, dynamic> json) => Restaurant(
        id: json["id"],
        name: json["name"],
        email: json["email"],
        emailVerifiedAt: json["email_verified_at"],
        createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
        phone: json["phone"],
        address: json["address"],
        roles: json["roles"],
        licensePlate: json["license_plate"],
        restaurantName: json["restaurant_name"],
        restaurantAddress: json["restaurant_address"],
        photo: json["photo"],
        latlong: json["latlong"],
        fcmId: json["fcm_id"],
    );

    Map<String, dynamic> toMap() => {
        "id": id,
        "name": name,
        "email": email,
        "email_verified_at": emailVerifiedAt,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "phone": phone,
        "address": address,
        "roles": roles,
        "license_plate": licensePlate,
        "restaurant_name": restaurantName,
        "restaurant_address": restaurantAddress,
        "photo": photo,
        "latlong": latlong,
        "fcm_id": fcmId,
    };
}
