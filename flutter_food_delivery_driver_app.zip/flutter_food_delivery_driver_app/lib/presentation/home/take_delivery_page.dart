import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_driver_app/presentation/home/bloc/tracking/tracking_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'package:flutter_food_delivery_driver_app/data/models/response/order_response_model.dart';
import 'package:location/location.dart';

import '../../../core/core.dart';
import 'models/direction.dart';

class TakeDeliveryPage extends StatefulWidget {
  final Order order;
  const TakeDeliveryPage({
    super.key,
    required this.order,
  });

  @override
  State<TakeDeliveryPage> createState() => _TakeDeliveryPageState();
}

class _TakeDeliveryPageState extends State<TakeDeliveryPage> {
  // final ruminateCoffe = const LatLng(-7.749868618509824, 110.3735274153414);
  // late GoogleMapController mapController;

  // Marker marker = const Marker(
  //   markerId: MarkerId('marker_1'),
  //   position: LatLng(-7.749868618509824, 110.3735274153414),
  //   infoWindow: InfoWindow(
  //       title: 'RUMINATE Coffee & Roastery',
  //       snippet:
  //           'Jl. Lempongsari Raya No.111, Sumberan, Sariharjo, Kec. Ngaglik, Kabupaten Sleman, Daerah Istimewa Yogyakarta 55581'),
  // );

  late GoogleMapController mapController;
  late final Set<Marker> markers = {};

  final Set<Polyline> polylines = <Polyline>{};

  final Location location = Location();

  BitmapDescriptor markerIcon = BitmapDescriptor.defaultMarker;

  BitmapDescriptor homeIcon = BitmapDescriptor.defaultMarker;

  void addCustomIcon() {
    BitmapDescriptor.fromAssetImage(
            const ImageConfiguration(size: Size(10, 10)),
            'assets/images/delivering.png')
        .then(
      (icon) {
        setState(() {
          markerIcon = icon;
        });
      },
    );
    // BitmapDescriptor.fromAssetImage(
    //         const ImageConfiguration(size: Size(10, 10)),
    //         'assets/markers/home2.png')
    //     .then(
    //   (icon) {
    //     setState(() {
    //       homeIcon = icon;
    //     });
    //   },
    // );
  }

  Future<void> setupLocation() async {
    late bool serviceEnabled;
    late PermissionStatus permissionGranted;

    serviceEnabled = await location.serviceEnabled();
    if (!serviceEnabled) {
      serviceEnabled = await location.requestService();
      if (!serviceEnabled) {
        debugPrint('location service is not available');
        return;
      }
    }

    permissionGranted = await location.hasPermission();
    if (permissionGranted == PermissionStatus.denied) {
      permissionGranted = await location.requestPermission();
      if (permissionGranted == PermissionStatus.denied) {
        debugPrint('Location permission is denied');
        return;
      }
    }
  }

  Future<void> setPolylines(LatLng origin, LatLng destination) async {
    final result = await Direction.getDirections(
      googleMapsApiKey: 'AIzaSyBrAj5OMzfef5gyHULhY0rQiuTaE39ZhD4',
      origin: origin,
      destination: destination,
    );

    final polylineCoordinates = <LatLng>[];
    if (result != null && result.polylinePoints.isNotEmpty) {
      polylineCoordinates.addAll(result.polylinePoints);
    }

    final polyline = Polyline(
      polylineId: const PolylineId('default-polyline'),
      color: Colors.green,
      width: 7,
      points: polylineCoordinates,
    );

    setState(() {
      polylines.add(polyline);
    });

    mapController.animateCamera(
      CameraUpdate.newLatLngBounds(result!.bounds, 50),
    );
  }

  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  @override
  void dispose() {
    mapController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    // mapController = GoogleMapController();
    super.initState();
    Future.microtask(() async {
      addCustomIcon();
      await setupLocation();
      markers.removeWhere((element) => element.markerId.value == 'source');
      markers.add(Marker(
          markerId: const MarkerId('source'),
          position: LatLng(
              widget.order.restaurant!.latlong!.split(',')[0].toDouble,
              widget.order.restaurant!.latlong!.split(',')[1].toDouble),
          icon:
              BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed)));
      markers.add(Marker(
          markerId: const MarkerId('des'),
          position: LatLng(widget.order.shippingLatlong!.split(',')[0].toDouble,
              widget.order.shippingLatlong!.split(',')[1].toDouble),
          icon:
              BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed)));

      await setPolylines(
          LatLng(widget.order.restaurant!.latlong!.split(',')[0].toDouble,
              widget.order.restaurant!.latlong!.split(',')[1].toDouble),
          LatLng(widget.order.shippingLatlong!.split(',')[0].toDouble,
              widget.order.shippingLatlong!.split(',')[1].toDouble));

      setState(() {});
    });

    location.onLocationChanged.listen((event) {
      context.read<TrackingBloc>().add(TrackingEvent.updateOrderTracking(
            currentLat: event.latitude.toString(),
            currentLong: event.longitude.toString(),
            orderStatus: 'on_the_way',
            orderId: widget.order.id!,
          ));
      // print('active');

      // print('active on');
      final latlng = LatLng(event.latitude!, event.longitude!);

      CameraPosition cameraPosition = CameraPosition(
        target: latlng,
        zoom: 16,
        tilt: 80,
        bearing: 30,
      );

      mapController.animateCamera(
        CameraUpdate.newCameraPosition(cameraPosition),
      );

      setState(() {
        markers.removeWhere((element) => element.markerId.value == 'source');
        markers.add(Marker(
          markerId: const MarkerId('source'),
          position: latlng,
          icon: markerIcon,
        ));
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(
              target: LatLng(
                  widget.order.restaurant!.latlong!.split(',')[0].toDouble,
                  widget.order.restaurant!.latlong!.split(',')[1].toDouble),
              zoom: 18,
            ),
            markers: markers,
            zoomControlsEnabled: false,
            mapToolbarEnabled: false,
            myLocationButtonEnabled: false,
            polylines: polylines,
            onMapCreated: (controller) {
              mapController = controller;
              final originMarker = Marker(
                markerId: const MarkerId('source'),
                position: LatLng(
                    widget.order.restaurant!.latlong!.split(',')[0].toDouble,
                    widget.order.restaurant!.latlong!.split(',')[1].toDouble),
                icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueRed,
                ),
              );

              final destinationMarker = Marker(
                markerId: const MarkerId('destination'),
                position: LatLng(
                    widget.order.shippingLatlong!.split(',')[0].toDouble,
                    widget.order.shippingLatlong!.split(',')[1].toDouble),
                icon: BitmapDescriptor.defaultMarkerWithHue(
                  BitmapDescriptor.hueRed,
                ),
              );

              setState(() {
                mapController = controller;
                markers.addAll([originMarker, destinationMarker]);
              });
            },
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(8.0, 38.0, 0, 0),
            child: IconButton(
              onPressed: () => context.pop(),
              icon: Assets.icons.backButton.svg(),
            ),
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(25.0)),
        child: ColoredBox(
          color: AppColors.white,
          child: Padding(
            padding: const EdgeInsets.all(14.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SpaceHeight(6.0),
                Container(
                  width: context.deviceWidth,
                  padding: const EdgeInsets.all(12.0),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(32.0),
                    color: AppColors.background,
                  ),
                  child: const Text(
                    'Your Trip is already on this way to you!',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: AppColors.primary,
                    ),
                  ),
                ),
                const SpaceHeight(27.0),
                Row(
                  children: [
                    SizedBox(
                      width: (context.deviceWidth / 2) - 14.0,
                      child: Row(
                        children: [
                          Assets.icons.locationCircle.svg(),
                          const SpaceWidth(12.0),
                          SizedBox(
                            width: context.deviceWidth - 280,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Delivery Address',
                                  style: TextStyle(
                                    fontSize: 12.0,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.gray2,
                                  ),
                                ),
                                const SpaceHeight(8.0),
                                Text(
                                  '${widget.order.shippingAddress}',
                                  style: const TextStyle(
                                    fontSize: 12.0,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.primary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: (context.deviceWidth / 2) - 14.0,
                      child: Row(
                        children: [
                          Assets.icons.distanceCircle.svg(),
                          const SpaceWidth(12.0),
                          const Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Distance',
                                style: TextStyle(
                                  fontSize: 12.0,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.gray2,
                                ),
                              ),
                              SpaceHeight(8.0),
                              Text(
                                '1.2 Km',
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 12.0,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.primary,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SpaceHeight(30.0),
                Row(
                  children: [
                    ClipOval(
                      child: CachedNetworkImage(
                        imageUrl:
                            'https://storage.googleapis.com/cdn.vcgamers.com/news/wp-content/uploads/2023/11/Screenshot-1545.png',
                        height: 44.0,
                        width: 44.0,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const SpaceWidth(15.0),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${widget.order.user?.name}',
                          style: const TextStyle(
                            color: AppColors.primary,
                          ),
                        ),
                        Text(
                          '${widget.order.user?.phone}',
                          style: const TextStyle(
                            color: AppColors.gray2,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SpaceHeight(30.0),
                Button.filled(
                  onPressed: () {
                    context.pop();
                  },
                  label: 'Pesanan Selesai',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
