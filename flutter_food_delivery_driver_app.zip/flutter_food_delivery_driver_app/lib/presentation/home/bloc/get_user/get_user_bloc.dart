import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'package:flutter_food_delivery_driver_app/data/datasources/auth_local_datasource.dart';

import '../../../../data/models/response/auth_response_model.dart';

part 'get_user_bloc.freezed.dart';
part 'get_user_event.dart';
part 'get_user_state.dart';

class GetUserBloc extends Bloc<GetUserEvent, GetUserState> {
  final AuthLocalDatasource datasource;
  GetUserBloc(
    this.datasource,
  ) : super(const _Initial()) {
    on<_GetUser>((event, emit) async {
      emit(const _Loading());
      try {
        final result = await datasource.getAuthData();
        emit(_Loaded(result.data!.user!));
      } catch (e) {
        emit(_Error(e.toString()));
      }
    });
  }
}
