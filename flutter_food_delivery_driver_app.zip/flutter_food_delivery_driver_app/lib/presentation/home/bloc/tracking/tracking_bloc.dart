import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'package:flutter_food_delivery_driver_app/data/datasources/firebase_firestore_remote_datasource.dart';

part 'tracking_bloc.freezed.dart';
part 'tracking_event.dart';
part 'tracking_state.dart';

class TrackingBloc extends Bloc<TrackingEvent, TrackingState> {
  final FirebaseFirestoreRemoteDatasource firebaseFirestoreRemoteDatasource;
  TrackingBloc(
    this.firebaseFirestoreRemoteDatasource,
  ) : super(const _Initial()) {
    on<_CreateOrderTracking>((event, emit) async {
      emit(const _Loading());
      try {
        await firebaseFirestoreRemoteDatasource.createOrderTracking(
          orderId: event.orderId,
          currentLat: event.currentLat,
          currentLong: event.currentLong,
          orderStatus: event.orderStatus,
        );
        emit(const _Success());
      } catch (e) {
        emit(_Error(e.toString()));
      }
    });
    on<_UpdateOrderTracking>((event, emit) async {
      emit(const _Loading());
      try {
        await firebaseFirestoreRemoteDatasource.updateOrderTracking(
          orderId: event.orderId,
          currentLat: event.currentLat,
          currentLong: event.currentLong,
          orderStatus: event.orderStatus,
        );
        emit(const _Success());
      } catch (e) {
        emit(_Error(e.toString()));
      }
    });
  }
}
