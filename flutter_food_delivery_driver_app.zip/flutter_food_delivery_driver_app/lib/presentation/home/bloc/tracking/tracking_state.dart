part of 'tracking_bloc.dart';

@freezed
class TrackingState with _$TrackingState {
  const factory TrackingState.initial() = _Initial;

  const factory TrackingState.loading() = _Loading;
  //error message
  const factory TrackingState.error(String message) = _Error;
  //success message
  const factory TrackingState.success() = _Success;
}
