part of 'tracking_bloc.dart';

@freezed
class TrackingEvent with _$TrackingEvent {
  const factory TrackingEvent.started() = _Started;
  const factory TrackingEvent.createOrderTracking({
    required int orderId,
    required String currentLat,
    required String currentLong,
    required String orderStatus,
  }) = _CreateOrderTracking;

  const factory TrackingEvent.updateOrderTracking({
    required int orderId,
    required String currentLat,
    required String currentLong,
    required String orderStatus,
  }) = _UpdateOrderTracking;
}