part of 'get_orders_bloc.dart';

@freezed
class GetOrdersState with _$GetOrdersState {
  const factory GetOrdersState.initial() = _Initial;
  const factory GetOrdersState.loading() = _Loading;
  const factory GetOrdersState.loaded(List<Order> orders) = _Loaded;
  const factory GetOrdersState.error(String message) = _Error;
}
