part of 'get_orders_bloc.dart';

@freezed
class GetOrdersEvent with _$GetOrdersEvent {
  const factory GetOrdersEvent.started() = _Started;
  const factory GetOrdersEvent.getOrders() = _GetOrders;
}