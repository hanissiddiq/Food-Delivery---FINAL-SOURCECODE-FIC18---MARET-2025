import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_driver_app/core/core.dart';
import 'package:flutter_food_delivery_driver_app/data/datasources/firebase_messaging_remote_datasource.dart';

import '../../data/datasources/auth_local_datasource.dart';
import '../auth/bloc/logout/logout_bloc.dart';
import '../auth/pages/login_page.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {

  @override
  void initState() {
    FirebaseMessagingRemoteDatasource().initialize();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Main Page'),
        actions: [
          BlocListener<LogoutBloc, LogoutState>(
            listener: (context, state) {
              state.maybeWhen(
                  orElse: () {},
                  success: () async {
                    await AuthLocalDatasource().removeAuthData();
                    context.pushReplacement(const LoginPage());
                  },
                  error: (error) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(error),
                      ),
                    );
                  });
            },
            child: IconButton(
              icon: const Icon(Icons.logout),
              onPressed: () {
                context.read<LogoutBloc>().add(const LogoutEvent.logout());
              },
            ),
          ),
        ],
      ),
      body: const Center(
        child: Text('Main Page'),
      ),
    );
  }
}
