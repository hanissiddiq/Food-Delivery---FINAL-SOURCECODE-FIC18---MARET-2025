import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_driver_app/core/constants/variables.dart';
import 'package:flutter_food_delivery_driver_app/data/models/response/order_response_model.dart';
import 'package:flutter_food_delivery_driver_app/presentation/home/bloc/get_orders/get_orders_bloc.dart';
import 'package:flutter_food_delivery_driver_app/presentation/home/bloc/tracking/tracking_bloc.dart';
import 'package:flutter_food_delivery_driver_app/presentation/home/bloc/update_status/update_status_bloc.dart';

import '../../../core/core.dart';
import '../models/order_list_model.dart';
import '../take_delivery_page.dart';

class ShippingList extends StatefulWidget {
  const ShippingList({super.key});

  @override
  State<ShippingList> createState() => _ShippingListState();
}

class _ShippingListState extends State<ShippingList> {
  @override
  void initState() {
    context.read<GetOrdersBloc>().add(const GetOrdersEvent.getOrders());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Daftar Pengiriman',
                style: TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              InkWell(
                onTap: () {},
                child: const Text(
                  'See all',
                  style: TextStyle(
                    fontSize: 12.0,
                    fontWeight: FontWeight.w600,
                    color: AppColors.gray4,
                  ),
                ),
              ),
            ],
          ),
          //refresh
          Center(
            child: ElevatedButton(
                onPressed: () {
                  context
                      .read<GetOrdersBloc>()
                      .add(const GetOrdersEvent.getOrders());
                },
                child: const Text('Refresh List')),
          ),
          ...[
            const SpaceHeight(14.0),
            BlocBuilder<GetOrdersBloc, GetOrdersState>(
              builder: (context, state) {
                return state.maybeWhen(orElse: () {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }, loaded: (products) {
                  return ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: products.length,
                    separatorBuilder: (context, index) =>
                        const SpaceHeight(11.0),
                    itemBuilder: (context, index) => ShippingCard(
                      item: products[index],
                    ),
                  );
                });
              },
            ),
          ]
        ],
      ),
    );
  }
}

class ShippingCard extends StatelessWidget {
  final Order item;
  const ShippingCard({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14.0),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(24.0),
        boxShadow: [
          BoxShadow(
            offset: const Offset(0, 0),
            blurRadius: 8.0,
            spreadRadius: 0,
            color: AppColors.stroke.withOpacity(0.5),
            blurStyle: BlurStyle.outer,
          )
        ],
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(16.0),
            child: CachedNetworkImage(
              imageUrl:
                  '${Variables.baseUrl}/storage/${item.restaurant?.photo}',
              fit: BoxFit.cover,
              width: 90.0,
              height: 90.0,
              placeholder: (context, url) =>
                  const Center(child: CircularProgressIndicator()),
            ),
          ),
          const SpaceWidth(28.0),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.restaurant?.restaurantName ?? '',
                style: const TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SpaceHeight(4.0),
              SizedBox(
                width: context.deviceWidth - 182.0,
                child: Text(
                  'Pelanggan : ${item.user?.name ?? ''}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12.0,
                    fontWeight: FontWeight.w500,
                    color: AppColors.gray2,
                  ),
                ),
              ),
              SizedBox(
                width: context.deviceWidth - 182.0,
                child: Text(
                  'Delivery Address : ${item.user?.address ?? ''}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12.0,
                    fontWeight: FontWeight.w500,
                    color: AppColors.gray2,
                  ),
                ),
              ),
              const SpaceHeight(8.0),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    // width: context.deviceWidth - 295.0,
                    child: Text(
                      item.totalBill!.currencyFormatRp,
                      style: const TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  const SpaceWidth(16.0),
                  InkWell(
                    borderRadius: BorderRadius.circular(16.0),
                    onTap: () {
                      context.read<UpdateStatusBloc>().add(
                            UpdateStatusEvent.updateStatus(
                              item.id!,
                              'on_the_way',
                            ),
                          );
                    },
                    child: BlocConsumer<UpdateStatusBloc, UpdateStatusState>(
                      listener: (context, state) {
                        state.maybeWhen(
                            orElse: () {},
                            success: () {
                              final restaurantLat = item.restaurant!.latlong!
                                  .split(',')
                                  .first
                                  .toDouble;
                              final restaurantLong = item.restaurant!.latlong!
                                  .split(',')
                                  .last
                                  .toDouble;
                              context.read<TrackingBloc>().add(
                                  TrackingEvent.createOrderTracking(
                                      orderId: item.id!,
                                      currentLat: restaurantLat.toString(),
                                      currentLong: restaurantLong.toString(),
                                      orderStatus: 'on_the_way'));
                              context.push(TakeDeliveryPage(
                                order: item,
                              ));
                            },
                            error: (error) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(error),
                                ),
                              );
                            });
                      },
                      builder: (context, state) {
                        return state.maybeWhen(
                          orElse: () => Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16.0, vertical: 8.0),
                            decoration: BoxDecoration(
                              color: AppColors.primary,
                              borderRadius: BorderRadius.circular(16.0),
                            ),
                            child: Text(
                              '${item.status == 'on_the_way' ? 'Show Map' : 'Take Delivery'} ',
                              style: TextStyle(
                                fontSize: 12.0,
                                color: AppColors.white,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          loading: () => Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16.0, vertical: 8.0),
                            decoration: BoxDecoration(
                              color: AppColors.primary,
                              borderRadius: BorderRadius.circular(16.0),
                            ),
                            child: const CircularProgressIndicator(
                              color: AppColors.white,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ],
          )
        ],
      ),
    );
  }
}
