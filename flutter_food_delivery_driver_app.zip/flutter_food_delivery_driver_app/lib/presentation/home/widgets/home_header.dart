import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_driver_app/core/constants/variables.dart';
import 'package:flutter_food_delivery_driver_app/data/datasources/auth_local_datasource.dart';
import 'package:flutter_food_delivery_driver_app/presentation/auth/bloc/logout/logout_bloc.dart';
import 'package:flutter_food_delivery_driver_app/presentation/auth/pages/login_page.dart';
import 'package:flutter_food_delivery_driver_app/presentation/home/bloc/get_user/get_user_bloc.dart';

import '../../../core/core.dart';

class RestoHeader extends StatefulWidget {
  const RestoHeader({super.key});

  @override
  State<RestoHeader> createState() => _RestoHeaderState();
}

class _RestoHeaderState extends State<RestoHeader> {
  @override
  void initState() {
    context.read<GetUserBloc>().add(const GetUserEvent.getUser());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.bottomCenter,
      children: [
        const ClipPath(
          clipper: CustomClip(),
          child: ColoredBox(
            color: AppColors.primary,
            child: SizedBox(
              height: 250.0,
              width: double.infinity,
            ),
          ),
        ),
        BlocBuilder<GetUserBloc, GetUserState>(
          builder: (context, state) {
            return state.maybeWhen(
              orElse: () => const SizedBox(),
              loading: () => const Center(child: CircularProgressIndicator()),
              loaded: (user) {
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 18.0),
                  padding: const EdgeInsets.fromLTRB(20.0, 36.0, 20.0, 20.0),
                  decoration: BoxDecoration(
                    color: AppColors.white,
                    borderRadius: BorderRadius.circular(12.0),
                    boxShadow: [
                      BoxShadow(
                        offset: const Offset(0, 4),
                        blurRadius: 20.0,
                        spreadRadius: 0,
                        color: AppColors.black.withOpacity(0.2),
                        blurStyle: BlurStyle.outer,
                      )
                    ],
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          ClipOval(
                            child: CachedNetworkImage(
                              imageUrl:
                                  '${Variables.baseUrl}/images/${user.photo}',
                              fit: BoxFit.cover,
                              width: 56.0,
                              height: 56.0,
                              placeholder: (context, url) => const Center(
                                  child: CircularProgressIndicator()),
                            ),
                          ),
                          const SpaceWidth(12.0),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '${user.name}',
                                style: const TextStyle(
                                  fontSize: 20.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SpaceHeight(4.0),
                              Row(
                                children: [
                                  Assets.icons.location.svg(),
                                  const SpaceWidth(8.0),
                                  Text(
                                    '${user.phone}',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.gray2,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          const Spacer(),
                          IconButton(
                            onPressed: () {
                              context
                                  .read<LogoutBloc>()
                                  .add(const LogoutEvent.logout());
                              AuthLocalDatasource().removeAuthData();
                              context.pushReplacement(const LoginPage());
                            },
                            icon: const Icon(
                              Icons.logout,
                              color: AppColors.primary,
                            ),
                          ),
                        ],
                      ),
                      const SpaceHeight(20.0),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Row(
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Plat Nomor',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const SpaceWidth(4.0),
                                Text(
                                  '${user.licensePlate}',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w500,
                                    color: AppColors.gray2,
                                    fontSize: 12.0,
                                  ),
                                ),
                              ],
                            ),
                            const Spacer(),
                            const Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Total Pengantaran',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                Text(
                                  '0',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    color: AppColors.gray2,
                                    fontSize: 12.0,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            );
          },
        ),
      ],
    );
  }
}

class CustomClip extends CustomClipper<Path> {
  const CustomClip();

  @override
  Path getClip(Size size) {
    var path = Path();
    path.lineTo(0, size.height * 0.75);
    path.quadraticBezierTo(
        size.width / 2, size.height, size.width, size.height * 0.75);
    path.lineTo(size.width, 0);
    return path;
  }

  @override
  bool shouldReclip(CustomClip oldClipper) {
    return false;
  }
}
