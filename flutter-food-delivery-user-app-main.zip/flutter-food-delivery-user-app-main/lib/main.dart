import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_user_app/data/datasources/order_remote_datasource.dart';
import 'package:flutter_food_delivery_user_app/data/datasources/restaurant_remote_datasource.dart';
import 'package:flutter_food_delivery_user_app/presentation/auth/pages/splash_page.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/checkout/checkout_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/current_restaurant/current_restaurant_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/get_history/get_history_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/get_products/get_products_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/get_restaurants/get_restaurants_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/get_user/get_user_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/order/order_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/purchase/purchase_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/update_status/update_status_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

import 'core/core.dart';
import 'data/datasources/auth_remote_datasource.dart';
import 'presentation/auth/bloc/login/login_bloc.dart';
import 'presentation/auth/bloc/logout/logout_bloc.dart';
import 'presentation/auth/bloc/register/register_bloc.dart';

import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => RegisterBloc(AuthRemoteDatasource()),
        ),
        BlocProvider(
          create: (context) => LoginBloc(AuthRemoteDatasource()),
        ),
        BlocProvider(
          create: (context) => LogoutBloc(AuthRemoteDatasource()),
        ),
        BlocProvider(
          create: (context) => GetRestaurantsBloc(RestaurantRemoteDatasource()),
        ),
        BlocProvider(
          create: (context) => GetUserBloc(AuthRemoteDatasource()),
        ),
        BlocProvider(
          create: (context) => GetProductsBloc(RestaurantRemoteDatasource()),
        ),
        BlocProvider(
          create: (context) => CheckoutBloc(),
        ),
        BlocProvider(
          create: (context) => CurrentRestaurantBloc(),
        ),
        BlocProvider(
          create: (context) => OrderBloc(OrderRemoteDatasource()),
        ),
        BlocProvider(
          create: (context) => PurchaseBloc(OrderRemoteDatasource()),
        ),
        BlocProvider(
          create: (context) => UpdateStatusBloc(OrderRemoteDatasource()),
        ),
        BlocProvider(
          create: (context) => GetHistoryBloc(OrderRemoteDatasource()),
        ),
      ],
      child: MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary),
          scaffoldBackgroundColor: AppColors.white,
          dividerTheme: const DividerThemeData(color: AppColors.divider),
          textTheme: GoogleFonts.interTextTheme(
            Theme.of(context).textTheme,
          ),
          appBarTheme: AppBarTheme(
            color: AppColors.primary,
            elevation: 0,
            titleTextStyle: GoogleFonts.inter(
              color: AppColors.white,
              fontSize: 16.0,
              fontWeight: FontWeight.w500,
            ),
            iconTheme: const IconThemeData(
              color: AppColors.white,
            ),
            centerTitle: true,
          ),
        ),
        home: const SplashPage(),
      ),
    );
  }
}
