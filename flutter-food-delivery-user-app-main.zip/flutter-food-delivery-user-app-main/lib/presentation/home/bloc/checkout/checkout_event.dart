part of 'checkout_bloc.dart';

@freezed
class CheckoutEvent with _$CheckoutEvent {
  const factory CheckoutEvent.started() = _Started;
  //additem
  const factory CheckoutEvent.addItem(
    Product product, {
    required Function() onDifferentRestaurantError,
    required Function() onSuccess,
  }) = _AddItem;
  //removeitem
  const factory CheckoutEvent.removeItem(Product product) = _RemoveItem;
  //update delivery cost
  const factory CheckoutEvent.updateDeliveryCost(
      String latlongRestaurant, String latlongUser) = _UpdateDeliveryCost;
}
