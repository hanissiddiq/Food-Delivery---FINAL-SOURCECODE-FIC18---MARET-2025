import 'dart:ui';

import 'package:bloc/bloc.dart';
import 'package:flutter_food_delivery_user_app/core/core.dart';
import 'package:flutter_food_delivery_user_app/core/utils/radius.dart';
import 'package:flutter_food_delivery_user_app/data/models/response/products_response_model.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../models/order_item_model.dart';

part 'checkout_event.dart';
part 'checkout_state.dart';
part 'checkout_bloc.freezed.dart';

class CheckoutBloc extends Bloc<CheckoutEvent, CheckoutState> {
  CheckoutBloc()
      : super(const _Success(
          [],
          0,
          0,
          10000,
        )) {
    on<_AddItem>((event, emit) {
      var currentState = state as _Success;

      List<OrderItemModel> newCheckout = [...currentState.products];
      final OrderItemModel lastItem;
      if (newCheckout.isEmpty) {
        lastItem = OrderItemModel(
            product: event.product, userId: event.product.userId!, quantity: 0);
      } else {
        lastItem = newCheckout[newCheckout.length - 1];
      }

      emit(const _Loading());
      if (lastItem.userId != event.product.userId) {
        event.onDifferentRestaurantError();
      } else if (newCheckout
          .any((element) => element.product == event.product)) {
        var index = newCheckout
            .indexWhere((element) => element.product == event.product);
        newCheckout[index].quantity++;
        event.onSuccess();
      } else {
        newCheckout.add(OrderItemModel(
            product: event.product,
            userId: event.product.userId!,
            quantity: 1));
        event.onSuccess();
      }

      int totalQuantity = 0;
      int totalPrice = 0;
      for (var element in newCheckout) {
        totalQuantity += element.quantity;
        totalPrice += element.quantity * element.product.price!;
      }

      emit(_Success(
          newCheckout, totalPrice, totalQuantity, currentState.deliveryCost));
    });

    on<_RemoveItem>((event, emit) {
      var currentState = state as _Success;
      List<OrderItemModel> newCheckout = [...currentState.products];
      emit(const _Loading());
      if (newCheckout.any((element) => element.product == event.product)) {
        var index = newCheckout
            .indexWhere((element) => element.product == event.product);

        if (newCheckout[index].quantity == 1) {
          newCheckout.removeAt(index);
        } else {
          newCheckout[index].quantity--;
        }
      }

      int totalQuantity = 0;
      int totalPrice = 0;
      for (var element in newCheckout) {
        totalQuantity += element.quantity;
        totalPrice += element.quantity * element.product.price!;
      }

      emit(_Success(
        newCheckout,
        totalQuantity,
        totalPrice,
        currentState.deliveryCost,
      ));
    });

    on<_Started>((event, emit) {
      emit(const _Loading());
      emit(const _Success(
        [],
        0,
        0,
        10000,
      ));
    });

    on<_UpdateDeliveryCost>((event, emit) {
      var currentState = state as _Success;
      emit(const _Loading());
      double calculateDistance = RadiusCalculate.calculateDistance(
        event.latlongRestaurant.split(',')[0].toDouble,
        event.latlongRestaurant.split(',')[1].toDouble,
        event.latlongUser.split(',')[0].toDouble,
        event.latlongUser.split(',')[1].toDouble,
      );
      int deliveryCost = calculateDistance.round() * 10000;
      emit(_Success(currentState.products, currentState.totalPrice,
          currentState.totalQuantity, deliveryCost));
    });
  }
}
