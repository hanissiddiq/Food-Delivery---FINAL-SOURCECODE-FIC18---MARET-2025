part of 'get_user_bloc.dart';

@freezed
class GetUserEvent with _$GetUserEvent {
  const factory GetUserEvent.started() = _Started;
  //getUser
  const factory GetUserEvent.getUser() = _GetUser;
  //updatelatlong
  const factory GetUserEvent.updateLatLong(
    double lat,
    double long,
    String address,
  ) = _UpdateLatLong;
}
