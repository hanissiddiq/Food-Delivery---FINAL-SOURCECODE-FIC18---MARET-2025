import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'package:flutter_food_delivery_user_app/data/datasources/auth_remote_datasource.dart';

import '../../../../data/models/response/auth_response_model.dart';

part 'get_user_bloc.freezed.dart';
part 'get_user_event.dart';
part 'get_user_state.dart';

class GetUserBloc extends Bloc<GetUserEvent, GetUserState> {
  final AuthRemoteDatasource datasource;
  GetUserBloc(
    this.datasource,
  ) : super(const _Initial()) {
    on<_GetUser>((event, emit) async{
      emit(const _Loading());
      final result = await datasource.getUser();
      result.fold(
        (l) => emit(_Error(l)),
        (r) => emit(_Loaded(r)),
      );
    });

    on<_UpdateLatLong>((event, emit) async{
      emit(const _Loading());
      final result = await datasource.updateLatLong(event.lat, event.long, event.address);
      result.fold(
        (l) => emit(_Error(l)),
        (r) => emit(_Loaded(r)),
      );
    });
  }
}
