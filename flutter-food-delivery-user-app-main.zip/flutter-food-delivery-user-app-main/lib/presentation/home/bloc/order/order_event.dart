part of 'order_bloc.dart';

@freezed
class OrderEvent with _$OrderEvent {
  const factory OrderEvent.started() = _Started;
  //process order
  const factory OrderEvent.processOrder(
    int restaurantid,
    int shippingCost,
    List<OrderItem> orderItems,
  ) = _ProcessOrder;
}