import 'package:bloc/bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/models/order_item_model.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'package:flutter_food_delivery_user_app/data/datasources/order_remote_datasource.dart';
import 'package:flutter_food_delivery_user_app/data/models/response/order_response_model.dart';

import '../../../../data/models/request/order_request_model.dart';

part 'order_bloc.freezed.dart';
part 'order_event.dart';
part 'order_state.dart';

class OrderBloc extends Bloc<OrderEvent, OrderState> {
  final OrderRemoteDatasource datasource;
  OrderBloc(
    this.datasource,
  ) : super(const _Initial()) {
    on<_ProcessOrder>((event, emit) async {
      emit(const _Loading());
      final data = OrderRequestModel(
        restaurantId: event.restaurantid,
        shippingCost: event.shippingCost,
        orderItems: event.orderItems,
      );
      final result = await datasource.order(data);
      result.fold(
        (l) => emit(_Error(l)),
        (r) => emit(_Success(r)),
      );
    });
  }
}
