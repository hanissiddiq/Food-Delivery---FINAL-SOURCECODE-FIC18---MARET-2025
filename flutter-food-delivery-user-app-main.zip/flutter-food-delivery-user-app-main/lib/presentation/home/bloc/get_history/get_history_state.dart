part of 'get_history_bloc.dart';

@freezed
class GetHistoryState with _$GetHistoryState {
  const factory GetHistoryState.initial() = _Initial;
  const factory GetHistoryState.loading() = _Loading;
  const factory GetHistoryState.loaded(List<OrderHistory> orders) = _Loaded;
  const factory GetHistoryState.error(String message) = _Error;
}
