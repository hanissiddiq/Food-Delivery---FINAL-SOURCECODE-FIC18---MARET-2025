part of 'purchase_bloc.dart';

@freezed
class PurchaseState with _$PurchaseState {
  const factory PurchaseState.initial() = _Initial;
  const factory PurchaseState.loading() = _Loading;
  const factory PurchaseState.error(String message) = _Error;
  const factory PurchaseState.success(PurchaseOrderResponseModel data) = _Success;
}
