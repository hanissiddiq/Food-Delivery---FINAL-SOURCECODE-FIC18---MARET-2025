part of 'purchase_bloc.dart';

@freezed
class PurchaseEvent with _$PurchaseEvent {
  const factory PurchaseEvent.started() = _Started;
  const factory PurchaseEvent.purchase({
    required String walletName,
    required int orderId,
  }) = _Purchase;
}