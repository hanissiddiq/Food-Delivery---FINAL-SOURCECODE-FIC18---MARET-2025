import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'package:flutter_food_delivery_user_app/data/datasources/order_remote_datasource.dart';
import 'package:flutter_food_delivery_user_app/data/models/response/purchase_order_response_model.dart';

part 'purchase_bloc.freezed.dart';
part 'purchase_event.dart';
part 'purchase_state.dart';

class PurchaseBloc extends Bloc<PurchaseEvent, PurchaseState> {
  final OrderRemoteDatasource datasource;
  PurchaseBloc(
    this.datasource,
  ) : super(const _Initial()) {
    on<_Purchase>((event, emit) async {
      emit(const _Loading());
      final result = await datasource.purchase(event.walletName, event.orderId);
      result.fold(
        (l) => emit(_Error(l)),
        (r) => emit(_Success(r)),
      );
    });
  }
}
