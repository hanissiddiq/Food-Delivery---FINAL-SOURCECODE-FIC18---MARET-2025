part of 'current_restaurant_bloc.dart';

@freezed
class CurrentRestaurantState with _$CurrentRestaurantState {
  const factory CurrentRestaurantState.initial() = _Initial;
  const factory CurrentRestaurantState.loading() = _Loading;
  const factory CurrentRestaurantState.error(String message) = _Error;
  const factory CurrentRestaurantState.success(Restaurant restaurant) = _Success;
}
