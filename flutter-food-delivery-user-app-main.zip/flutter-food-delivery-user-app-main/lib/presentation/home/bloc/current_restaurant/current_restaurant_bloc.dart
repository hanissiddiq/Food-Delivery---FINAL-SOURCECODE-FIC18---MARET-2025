import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../../../data/models/response/all_restaurant_response_model.dart';

part 'current_restaurant_event.dart';
part 'current_restaurant_state.dart';
part 'current_restaurant_bloc.freezed.dart';

class CurrentRestaurantBloc extends Bloc<CurrentRestaurantEvent, CurrentRestaurantState> {
  CurrentRestaurantBloc() : super(const _Initial()) {
    on<_SetRestaurant>((event, emit) {
      emit(const _Loading());
      emit(_Success(event.restaurant));
    });
  }
}
