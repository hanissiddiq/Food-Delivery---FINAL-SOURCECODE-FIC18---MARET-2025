part of 'current_restaurant_bloc.dart';

@freezed
class CurrentRestaurantEvent with _$CurrentRestaurantEvent {
  const factory CurrentRestaurantEvent.started() = _Started;
  //set restaurant
  const factory CurrentRestaurantEvent.setRestaurant(Restaurant restaurant) = _SetRestaurant;
}