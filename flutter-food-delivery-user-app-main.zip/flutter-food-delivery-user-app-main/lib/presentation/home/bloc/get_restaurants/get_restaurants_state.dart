part of 'get_restaurants_bloc.dart';

@freezed
class GetRestaurantsState with _$GetRestaurantsState {
  const factory GetRestaurantsState.initial() = _Initial;
  const factory GetRestaurantsState.loading() = _Loading;
  const factory GetRestaurantsState.loaded(List<Restaurant> restaurants) = _Loaded;
  const factory GetRestaurantsState.error(String message) = _Error;
}
