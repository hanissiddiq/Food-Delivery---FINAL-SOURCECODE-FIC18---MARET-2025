import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'package:flutter_food_delivery_user_app/data/datasources/restaurant_remote_datasource.dart';

import '../../../../data/models/response/all_restaurant_response_model.dart';

part 'get_restaurants_bloc.freezed.dart';
part 'get_restaurants_event.dart';
part 'get_restaurants_state.dart';

class GetRestaurantsBloc
    extends Bloc<GetRestaurantsEvent, GetRestaurantsState> {
  final RestaurantRemoteDatasource datasource;
  GetRestaurantsBloc(
    this.datasource,
  ) : super(const _Initial()) {
    on<_GetAll>((event, emit) async {
      emit(const _Loading());
      final response = await datasource.getRestaurants();
      response.fold(
        (l) => emit(_Error(l)),
        (r) => emit(_Loaded(r.data ?? [])),
      );
    });
  }
}
