part of 'get_restaurants_bloc.dart';

@freezed
class GetRestaurantsEvent with _$GetRestaurantsEvent {
  const factory GetRestaurantsEvent.started() = _Started;
  const factory GetRestaurantsEvent.getAll() = _GetAll;

}