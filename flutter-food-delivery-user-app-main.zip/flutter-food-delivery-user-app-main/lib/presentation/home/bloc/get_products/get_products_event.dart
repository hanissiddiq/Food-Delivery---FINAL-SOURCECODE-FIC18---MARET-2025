part of 'get_products_bloc.dart';

@freezed
class GetProductsEvent with _$GetProductsEvent {
  const factory GetProductsEvent.started() = _Started;
  //getProductByRestaurantId
  const factory GetProductsEvent.getProductsByRestaurantId(int restaurantId) = _GetProductsByRestaurantId;
}