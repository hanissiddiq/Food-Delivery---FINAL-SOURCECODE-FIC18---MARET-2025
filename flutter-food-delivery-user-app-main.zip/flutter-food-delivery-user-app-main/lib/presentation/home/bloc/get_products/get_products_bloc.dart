import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'package:flutter_food_delivery_user_app/data/datasources/restaurant_remote_datasource.dart';

import '../../../../data/models/response/products_response_model.dart';

part 'get_products_bloc.freezed.dart';
part 'get_products_event.dart';
part 'get_products_state.dart';

class GetProductsBloc extends Bloc<GetProductsEvent, GetProductsState> {
  final RestaurantRemoteDatasource datasource;
  GetProductsBloc(
    this.datasource,
  ) : super(const _Initial()) {
    on<_GetProductsByRestaurantId>((event, emit) async {
      emit(const _Loading());
      final result = await datasource.getProducts(event.restaurantId);
      result.fold(
        (l) => emit(_Error(l)),
        (r) => emit(_Loaded(r.data ?? [])),
      );
    });
  }
}
