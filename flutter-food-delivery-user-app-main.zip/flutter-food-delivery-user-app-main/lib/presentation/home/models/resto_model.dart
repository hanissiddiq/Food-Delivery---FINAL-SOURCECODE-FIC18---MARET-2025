class RestoModel {
  final String imageUrl;
  final String restoName;
  final String address;

  RestoModel({
    required this.imageUrl,
    required this.restoName,
    required this.address,
  });
}

final restoList = [
  RestoModel(
    imageUrl: 'https://imgcdn.solopos.com/@space/2022/10/gacoan.jpg',
    restoName: 'Mie Gacoan',
    address: 'Jalan Kalimaya No. 34',
  ),
  RestoModel(
    imageUrl:
        'https://lh5.googleusercontent.com/p/AF1QipOln2Ov-mfcLuh0ZEajsFoLq3cCqOPRVsg5ke5M=w500-h500-k-no',
    restoName: 'Kopi Kenangan',
    address: 'Galeria Mall - Yogyakarta City',
  ),
  RestoModel(
    imageUrl:
        'https://assets-pergikuliner.com/uploads/image/picture/1434259/picture-1559971256.jpg',
    restoName: 'Janji Jiwa',
    address: 'Hartono Mall - Yogyakarta City',
  ),
  RestoModel(
    imageUrl:
        'https://www.doku.com/blog/wp-content/uploads/2024/02/Waas-tomoro-2-1200x800.jpg',
    restoName: 'Tomoro Coffee',
    address: 'Jalan Kaliurang No. 34',
  ),
  RestoModel(
    imageUrl:
        'https://d1r9hss9q19p18.cloudfront.net/uploads/2019/02/Fore-Coffee-1.jpg',
    restoName: 'Fore Coffee',
    address: 'Jalan Kaliurang No. 44',
  ),
  RestoModel(
    imageUrl:
        'https://flash-coffee.com/wp-content/uploads/2022/05/Flash-Coffee-orchardgateway-23.jpg',
    restoName: 'Flash Coffee',
    address: 'Pakuwon Mall - Yogyakarta City',
  ),
];
