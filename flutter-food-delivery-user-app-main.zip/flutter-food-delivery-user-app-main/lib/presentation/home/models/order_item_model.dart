// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter_food_delivery_user_app/data/models/response/products_response_model.dart';

import '../../../data/models/request/order_request_model.dart';

class OrderItemModel {
  Product product;
  int quantity;
  int userId;

  OrderItemModel({
    required this.product,
    required this.quantity,
    required this.userId,
  });

  //toOrderItem
  OrderItem toOrderItem() {
    return OrderItem(
      productId: product.id!,
      quantity: quantity,
    );
  }
}
