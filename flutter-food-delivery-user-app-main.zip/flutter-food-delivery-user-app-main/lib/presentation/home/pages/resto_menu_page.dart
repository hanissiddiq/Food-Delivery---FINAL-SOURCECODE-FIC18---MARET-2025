import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:flutter_food_delivery_user_app/data/models/response/all_restaurant_response_model.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/current_restaurant/current_restaurant_bloc.dart';

import '../../../core/components/components.dart';
import '../widgets/choose_menu.dart';
import '../widgets/resto_header.dart';

class RestoMenuPage extends StatefulWidget {
  final Restaurant restaurant;
  const RestoMenuPage({
    super.key,
    required this.restaurant,
  });

  @override
  State<RestoMenuPage> createState() => _RestoMenuPageState();
}

class _RestoMenuPageState extends State<RestoMenuPage> {
  @override
  void initState() {
    context
        .read<CurrentRestaurantBloc>()
        .add(CurrentRestaurantEvent.setRestaurant(widget.restaurant));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          RestoHeader(
            restaurant: widget.restaurant,
          ),
          const SpaceHeight(30.0),
          ChooseMenu(
            restaurant: widget.restaurant,
          ),
          const SpaceHeight(30.0),
        ],
      ),
    );
  }
}
