import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_user_app/core/core.dart';

import 'package:flutter_food_delivery_user_app/data/models/response/purchase_order_response_model.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/get_history/get_history_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/update_status/update_status_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/pages/main_page.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../bloc/checkout/checkout_bloc.dart';

class XenditPaymentPage extends StatefulWidget {
  final PurchaseOrderResponseModel data;
  const XenditPaymentPage({
    super.key,
    required this.data,
  });

  @override
  State<XenditPaymentPage> createState() => _XenditPaymentPageState();
}

class _XenditPaymentPageState extends State<XenditPaymentPage> {
  late final WebViewController _controller;
  //late final Timer timer;
  bool isLoading = false;

  Future<void> _handlePaymentSuccess() async {
    context.showDialogSuccess(
      'Pembayaran Berhasil',
      'Pesanan kamu akan segera ditinjau dan diproses oleh kami ya, tunggu notifikasi selanjutnya.',
    );

    await Future.delayed(const Duration(seconds: 3));
    if (mounted) {
      context.pushReplacement(const MainPage());
      // context.push(OrderStatusAfterPayment(
      //   orderData: widget.orderData,
      // ));
      context.read<GetHistoryBloc>().add(const GetHistoryEvent.getHistories());
      context.read<CheckoutBloc>().add(const CheckoutEvent.started());
    }
  }

  Future<void> _handlePaymentFailure() async {
    context.showDialogError(
      'Pembayaran Gagal',
      'Ops. Terjadi kesalahan, mohon ulangi sesaat lagi ya, Sob.',
    );

    if (mounted) {
      context.popToRoot();
    }
  }

  @override
  void initState() {
    const PlatformWebViewControllerCreationParams params =
        PlatformWebViewControllerCreationParams();
    _controller = WebViewController.fromPlatformCreationParams(params);
    _controller
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            debugPrint('WebView is loading (progress : $progress%)');
          },
          onPageStarted: (String url) {
            setState(() => isLoading = true);
            debugPrint('Page started loading: $url');
          },
          onPageFinished: (String url) {
            setState(() => isLoading = false);
            debugPrint('Page finished loading: $url');
          },
          onNavigationRequest: (NavigationRequest request) {
            if (request.url.contains('flutter://payment_success')) {
              context.read<UpdateStatusBloc>().add(
                    UpdateStatusEvent.updateStatus(
                      orderId: widget.data.order!.id!,
                      status: 'processing',
                    ),
                  );
              _handlePaymentSuccess();
              return NavigationDecision.prevent;
            } else if (request.url.contains('flutter://payment_failed')) {
              _handlePaymentFailure();
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
          onWebResourceError: (WebResourceError error) {
            debugPrint('''
              Page resource error:
              code: ${error.errorCode}
              description: ${error.description}
              errorType: ${error.errorType}
              isForMainFrame: ${error.isForMainFrame}
          ''');
          },
        ),
      )
      ..addJavaScriptChannel(
        'Toaster',
        onMessageReceived: (JavaScriptMessage message) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(message.message)),
          );
        },
      )
      ..loadRequest(Uri.parse(widget.data.payment!.actions![0].url!));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(child: WebViewWidget(controller: _controller)),
    );
  }
}
