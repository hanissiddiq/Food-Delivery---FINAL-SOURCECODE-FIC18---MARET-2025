import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../core/core.dart';
import '../bloc/get_history/get_history_bloc.dart';
import '../models/product_model.dart';
import '../widgets/history_card.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  @override
  void initState() {
    context.read<GetHistoryBloc>().add(const GetHistoryEvent.getHistories());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('History'),
        actions: [
          IconButton(
            onPressed: () {
              context
                  .read<GetHistoryBloc>()
                  .add(const GetHistoryEvent.getHistories());
            },
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: BlocBuilder<GetHistoryBloc, GetHistoryState>(
        builder: (context, state) {
          return state.maybeWhen(
            orElse: () {
              return const Center(
                child: CircularProgressIndicator(),
              );
            },
            loaded: (orders) {
              return ListView.separated(
                padding: const EdgeInsets.all(20.0),
                itemCount: orders.length,
                separatorBuilder: (context, index) => const SpaceHeight(10.0),
                itemBuilder: (context, index) => HistoryCard(
                  histories: orders.reversed.toList()[index],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
