import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_user_app/data/datasources/firebase_firestore_remote_datasource.dart';
import 'package:flutter_food_delivery_user_app/data/models/response/order_history_response_model.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/get_history/get_history_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/update_status/update_status_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';

import '../../../core/core.dart';
import '../models/direction.dart';
import '../models/track_record_model.dart';
import '../widgets/tracking_vertical.dart';
import 'order_complete_page.dart';

class OrderStatusAfterPayment extends StatefulWidget {
  final OrderHistory orderHistory;
  const OrderStatusAfterPayment({
    super.key,
    required this.orderHistory,
  });

  @override
  State<OrderStatusAfterPayment> createState() =>
      _OrderStatusAfterPaymentState();
}

class _OrderStatusAfterPaymentState extends State<OrderStatusAfterPayment> {
  late GoogleMapController mapController;
  late final Set<Marker> markers = {};

  final Set<Polyline> polylines = <Polyline>{};

  final Location location = Location();

  BitmapDescriptor markerIcon = BitmapDescriptor.defaultMarker;

  BitmapDescriptor homeIcon = BitmapDescriptor.defaultMarker;

  void addCustomIcon() {
    BitmapDescriptor.fromAssetImage(
            const ImageConfiguration(size: Size(10, 10)),
            'assets/images/delivering.png')
        .then(
      (icon) {
        setState(() {
          markerIcon = icon;
        });
      },
    );
  }

  Future<void> setupLocation() async {
    late bool serviceEnabled;
    late PermissionStatus permissionGranted;

    serviceEnabled = await location.serviceEnabled();
    if (!serviceEnabled) {
      serviceEnabled = await location.requestService();
      if (!serviceEnabled) {
        debugPrint('location service is not available');
        return;
      }
    }

    permissionGranted = await location.hasPermission();
    if (permissionGranted == PermissionStatus.denied) {
      permissionGranted = await location.requestPermission();
      if (permissionGranted == PermissionStatus.denied) {
        debugPrint('Location permission is denied');
        return;
      }
    }
  }

  Future<void> setPolylines(LatLng origin, LatLng destination) async {
    final result = await Direction.getDirections(
      googleMapsApiKey: 'your google maps api key',
      origin: origin,
      destination: destination,
    );

    final polylineCoordinates = <LatLng>[];
    if (result != null && result.polylinePoints.isNotEmpty) {
      polylineCoordinates.addAll(result.polylinePoints);
    }

    final polyline = Polyline(
      polylineId: const PolylineId('default-polyline'),
      color: Colors.green,
      width: 7,
      points: polylineCoordinates,
    );

    setState(() {
      polylines.add(polyline);
    });

    mapController.animateCamera(
      CameraUpdate.newLatLngBounds(result!.bounds, 50),
    );
  }

  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  @override
  void dispose() {
    mapController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    // mapController = GoogleMapController();
    super.initState();
    Future.microtask(() async {
      addCustomIcon();
      await setupLocation();
      markers.removeWhere((element) => element.markerId.value == 'source');
      markers.add(Marker(
          markerId: const MarkerId('source'),
          position: LatLng(
              widget.orderHistory.restaurant!.latlong!.split(',')[0].toDouble,
              widget.orderHistory.restaurant!.latlong!.split(',')[1].toDouble),
          icon:
              BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed)));
      markers.add(Marker(
          markerId: const MarkerId('des'),
          position: LatLng(
              widget.orderHistory.shippingLatlong!.split(',')[0].toDouble,
              widget.orderHistory.shippingLatlong!.split(',')[1].toDouble),
          icon:
              BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed)));

      await setPolylines(
          LatLng(
              widget.orderHistory.restaurant!.latlong!.split(',')[0].toDouble,
              widget.orderHistory.restaurant!.latlong!.split(',')[1].toDouble),
          LatLng(widget.orderHistory.shippingLatlong!.split(',')[0].toDouble,
              widget.orderHistory.shippingLatlong!.split(',')[1].toDouble));

      setState(() {});
    });

    FirebaseFirestoreRemoteDatasource.instance
        .readOrderTracking(orderId: widget.orderHistory.id!)
        .listen((event) {
      final latlng =
          LatLng(event.currentLat.toDouble, event.currentLong.toDouble);

      CameraPosition cameraPosition = CameraPosition(
        target: latlng,
        zoom: 16,
        tilt: 80,
        bearing: 30,
      );

      mapController.animateCamera(
        CameraUpdate.newCameraPosition(cameraPosition),
      );

      setState(() {
        markers.removeWhere((element) => element.markerId.value == 'source');
        markers.add(Marker(
          markerId: const MarkerId('source'),
          position: latlng,
          icon: markerIcon,
        ));
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          GoogleMap(
            onMapCreated: _onMapCreated,
            initialCameraPosition: CameraPosition(
              target: LatLng(
                widget.orderHistory.restaurant!.latlong!.split(',')[0].toDouble,
                widget.orderHistory.restaurant!.latlong!.split(',')[1].toDouble,
              ),
              zoom: 16,
            ),
            markers: markers,
            polylines: polylines,
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(8.0, 38.0, 0, 0),
            child: IconButton(
              onPressed: () => context.pop(),
              icon: Assets.icons.backButton.svg(),
            ),
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: GestureDetector(
        onVerticalDragStart: (details) => showModalBottomSheet(
          context: context,
          isScrollControlled: false, // TODO: do true when order is delivering
          useSafeArea: true,
          showDragHandle: true,
          backgroundColor: AppColors.white,
          builder: (context) => OrderStatusBottomSheet(
            orderHistory: widget.orderHistory,
          ),
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(25.0)),
          child: ColoredBox(
            color: AppColors.white,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(
                    width: 48.0,
                    child: ClipRRect(
                      borderRadius: BorderRadius.all(Radius.circular(100.0)),
                      child: Divider(
                        color: AppColors.gray2,
                        thickness: 4.0,
                      ),
                    ),
                  ),
                  const SpaceHeight(17.0),
                  Row(
                    children: [
                      const SpaceWidth(10.0),
                      Assets.images.orderStatus.delivering.image(height: 44.0),
                      const SpaceWidth(10.0),
                      const Text(
                        'Delivering your order',
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  const SpaceHeight(20.0),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class OrderStatusBottomSheet extends StatelessWidget {
  final OrderHistory orderHistory;
  const OrderStatusBottomSheet({super.key, required this.orderHistory});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(8.0),
      children: [
        Row(
          children: [
            const SpaceWidth(10.0),
            Assets.images.orderStatus.delivering.image(height: 44.0),
            const SpaceWidth(10.0),
            const Text(
              'Delivering your order',
              style: TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        const SpaceHeight(27.0),
        const SpaceHeight(16.0),
        Button.filled(
          onPressed: () {
            context.read<UpdateStatusBloc>().add(
                  UpdateStatusEvent.updateStatus(
                    orderId: orderHistory.id!,
                    status: 'completed',
                  ),
                );
            context
                .read<GetHistoryBloc>()
                .add(const GetHistoryEvent.getHistories());
            context.push(const OrderCompletePage());
          },
          label: 'Pesanan di Terima',
        ),
      ],
    );
  }
}
