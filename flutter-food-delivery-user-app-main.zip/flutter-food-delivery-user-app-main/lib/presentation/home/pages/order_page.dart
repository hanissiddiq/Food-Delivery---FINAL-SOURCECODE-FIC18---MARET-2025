import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/checkout/checkout_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/get_user/get_user_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/order/order_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/models/order_item_model.dart';

import '../../../core/core.dart';
import '../../../data/models/request/order_request_model.dart';
import '../bloc/current_restaurant/current_restaurant_bloc.dart';
import '../models/product_model.dart';
import '../widgets/order_card.dart';
import '../widgets/order_delivery_address.dart';
import '../widgets/order_summary.dart';
import 'payment_page.dart';

class OrderPage extends StatefulWidget {
  const OrderPage({super.key});

  @override
  State<OrderPage> createState() => _OrderPageState();
}

class _OrderPageState extends State<OrderPage> {
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Order'),
      ),
      body:
          // orders.isEmpty
          //     ? Center(
          //         child: Column(
          //           mainAxisAlignment: MainAxisAlignment.center,
          //           children: [
          //             Assets.icons.alert.empty.svg(),
          //             const SpaceHeight(20.0),
          //             const Text(
          //               'Belum ada Pesanan',
          //               style: TextStyle(
          //                 fontSize: 18.0,
          //                 fontWeight: FontWeight.bold,
          //               ),
          //             ),
          //           ],
          //         ),
          //       )
          //     :
          BlocBuilder<CheckoutBloc, CheckoutState>(
        builder: (context, state) {
          List<OrderItemModel> orders = [];
          // int totalPrice = 0;
          // int totalQuantity = 0;
          state.maybeWhen(
            orElse: () {},
            success: (order, totalPrice, totalQuantity, deliveryCost) {
              orders = order;
              // totalPrice = totalPrice;
              // totalQuantity = totalQuantity;
            },
          );
          if (orders.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Assets.icons.alert.empty.svg(),
                  const SpaceHeight(20.0),
                  const Text(
                    'Belum ada Pesanan',
                    style: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            );
          }
          return ListView(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            children: [
              const SpaceHeight(16.0),
              const OrderDeliveryAddress(),
              const SpaceHeight(20.0),
              ListView.separated(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: orders.length,
                separatorBuilder: (context, index) => const SpaceHeight(10.0),
                itemBuilder: (context, index) => OrderCard(
                  item: orders[index],
                ),
              ),
              const SpaceHeight(40.0),
              const OrderSummary(),
              const SpaceHeight(36.0),
              BlocBuilder<CurrentRestaurantBloc, CurrentRestaurantState>(
                builder: (context, state) {
                  int restaurantId = 0;
                  state.maybeWhen(
                    orElse: () {},
                    success: (restaurant) {
                      restaurantId = restaurant.id!;
                    },
                  );
                  return BlocBuilder<CheckoutBloc, CheckoutState>(
                    builder: (context, state) {
                      int shippingCost = 0;
                      List<OrderItem> orders = [];
                      state.maybeWhen(
                        orElse: () {},
                        success:
                            (order, totalPrice, totalQuantity, deliveryCost) {
                          orders = order.map((e) => e.toOrderItem()).toList();
                          shippingCost = deliveryCost;
                        },
                      );
                      return BlocListener<OrderBloc, OrderState>(
                        listener: (context, state) {
                          state.maybeWhen(
                            orElse: () {},
                            success: (order) {
                              context.push(PaymentPage(
                                order: order,
                              ));
                            },
                          );
                        },
                        child: BlocBuilder<OrderBloc, OrderState>(
                          builder: (context, state) {
                            return state.maybeWhen(
                              orElse: () {
                                return BlocBuilder<GetUserBloc, GetUserState>(
                                  builder: (context, state) {
                                    return state.maybeWhen(
                                      orElse: () {
                                        return const SizedBox();
                                      },
                                      loaded: (user) {
                                        return Button.filled(
                                          onPressed: () {
                                            if (user.address == null) {
                                              context.showDialogError(
                                                  'Alamat Kosong',
                                                  'Alamat pengiriman belum tersedia. Silakan tambahkan alamat untuk melanjutkan.');
                                            } else {
                                              context.read<OrderBloc>().add(
                                                    OrderEvent.processOrder(
                                                      restaurantId,
                                                      shippingCost,
                                                      orders,
                                                    ),
                                                  );
                                            }
                                          },
                                          label: 'Pesan Sekarang',
                                        );
                                      },
                                    );
                                  },
                                );
                              },
                              loading: () {
                                return const Center(
                                  child: CircularProgressIndicator(),
                                );
                              },
                            );
                          },
                        ),
                      );
                    },
                  );
                },
              ),
              const SpaceHeight(30.0),
            ],
          );
        },
      ),
    );
  }
}
