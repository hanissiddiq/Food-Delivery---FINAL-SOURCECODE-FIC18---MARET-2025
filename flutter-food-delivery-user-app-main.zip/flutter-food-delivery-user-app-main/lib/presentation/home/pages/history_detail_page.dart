import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_user_app/data/models/response/order_history_response_model.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/get_history/get_history_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/pages/order_status_after_payment.dart';

import '../../../core/core.dart';
import '../widgets/history_product_card.dart';

class HistoryDetailPage extends StatelessWidget {
  final OrderHistory orderHistory;
  const HistoryDetailPage({super.key, required this.orderHistory});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('History'),
        actions: [
          IconButton(
            onPressed: () {
              context
                  .read<GetHistoryBloc>()
                  .add(const GetHistoryEvent.getHistories());
              context.pop();
            },
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 18.0, vertical: 20.0),
        children: [
          const Text(
            'Metode Pembayaran',
            style: TextStyle(
              fontSize: 16.0,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SpaceHeight(12.0),
          Text(
            orderHistory.paymentMethod ?? '',
            style: const TextStyle(
              fontSize: 16.0,
              fontWeight: FontWeight.w500,
            ),
          ),
          // Image.asset(
          //   alignment: Alignment.centerLeft,
          //   Assets.images.payments.ovo.path,
          //   height: 30.0,
          // ),
          const SpaceHeight(6.0),
          const Text(
            'Bayar melalui ewallet',
            style: TextStyle(
              fontSize: 12.0,
              color: AppColors.gray3,
            ),
          ),
          const SpaceHeight(30.0),
          const Text(
            'Pesanan Kamu',
            style: TextStyle(
              fontSize: 16.0,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SpaceHeight(20.0),
          const DottedDivider(),
          const SpaceHeight(18.0),
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: orderHistory.orderItems!.length,
            separatorBuilder: (context, index) => const Divider(height: 36.0),
            itemBuilder: (context, index) => HistoryProductCard(
              item: orderHistory.orderItems![index],
            ),
          ),
          const SpaceHeight(18.0),
          const Divider(),
          const SpaceHeight(24.0),
          const Text(
            'Detail Pesanan',
            style: TextStyle(
              fontSize: 16.0,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SpaceHeight(20.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'No Pesanan',
                style: TextStyle(
                  color: AppColors.gray3,
                ),
              ),
              Text(
                'INV-${orderHistory.id}',
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          const SpaceHeight(20.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Tanggal Pesanan',
                style: TextStyle(
                  color: AppColors.gray3,
                ),
              ),
              Text(
                orderHistory.createdAt!.toFormattedDateTime(),
                style: const TextStyle(
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          const SpaceHeight(20.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Atas Nama',
                style: TextStyle(
                  color: AppColors.gray3,
                ),
              ),
              Text(
                orderHistory.user!.name ?? '',
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          const SpaceHeight(40.0),
          const Text(
            'Rincian Biaya',
            style: TextStyle(
              fontSize: 16.0,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SpaceHeight(20.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Harga',
                style: TextStyle(
                  color: AppColors.gray3,
                ),
              ),
              Text(
                orderHistory.totalPrice!.currencyFormatRp,
                style: const TextStyle(
                  color: AppColors.gray3,
                ),
              ),
            ],
          ),
          const SpaceHeight(20.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Ongkos Kirim',
                style: TextStyle(
                  color: AppColors.gray3,
                ),
              ),
              Text(
                orderHistory.shippingCost!.currencyFormatRp,
                style: const TextStyle(
                  color: AppColors.gray3,
                ),
              ),
            ],
          ),
          const SpaceHeight(20.0),
          const DottedDivider(),
          const SpaceHeight(20.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Total Pembayaran',
                style: TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                orderHistory.totalBill!.currencyFormatRp,
                style: const TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.w700,
                  color: AppColors.primary,
                ),
              ),
            ],
          ),
          const SpaceHeight(30.0),
          Button.filled(
            onPressed: () {
              if (orderHistory.status != 'on_the_way') {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Status Pesanan ${orderHistory.status}'),
                  ),
                );
              } else {
                context.push(OrderStatusAfterPayment(
                  orderHistory: orderHistory,
                ));
              }
            },
            label: 'Lihat Status Pesanan',
          ),
        ],
      ),
    );
  }
}
