import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_user_app/core/constants/variables.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/get_user/get_user_bloc.dart';
import 'package:shimmer/shimmer.dart';

import '../../../core/core.dart';

class ProfileHeader extends StatelessWidget {
  const ProfileHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.bottomCenter,
      children: [
        const Padding(
          padding: EdgeInsets.only(bottom: 16.0),
          child: ClipPath(
            clipper: CustomClip(),
            child: ColoredBox(
              color: AppColors.primary,
              child: SizedBox(
                height: 250.0,
                width: double.infinity,
              ),
            ),
          ),
        ),
        BlocBuilder<GetUserBloc, GetUserState>(
          builder: (context, state) {
            return state.maybeWhen(
              loaded: (user) => ClipOval(
                child: CachedNetworkImage(
                  imageUrl: '${Variables.baseUrl}/images/${user.photo}',
                  fit: BoxFit.cover,
                  width: 110.0,
                  height: 110.0,
                  placeholder: (context, url) =>
                      const Center(child: CircularProgressIndicator()),
                ),
              ),
              orElse: () => SizedBox(
                width: 110.0,
                height: 110.0,
                child: Shimmer.fromColors(
                  baseColor: Colors.grey,
                  highlightColor: Colors.white,
                  period: const Duration(seconds: 1),
                  direction: ShimmerDirection.ltr,
                  child: Container(
                    width: 110.0,
                    height: 110.0,
                    decoration: const BoxDecoration(
                        shape: BoxShape.circle, color: Colors.grey),
                  ),
                ),
              ),
            );
          },
        ),
        Padding(
          padding: const EdgeInsets.only(left: 80.0),
          child: IconButton(
            onPressed: () {},
            icon: Assets.icons.editCircle.svg(),
            padding: EdgeInsets.zero,
          ),
        ),
      ],
    );
  }
}

class CustomClip extends CustomClipper<Path> {
  const CustomClip();

  @override
  Path getClip(Size size) {
    var path = Path();
    path.lineTo(0, size.height * 0.75);
    path.quadraticBezierTo(
        size.width / 2, size.height, size.width, size.height * 0.75);
    path.lineTo(size.width, 0);
    return path;
  }

  @override
  bool shouldReclip(CustomClip oldClipper) {
    return false;
  }
}
