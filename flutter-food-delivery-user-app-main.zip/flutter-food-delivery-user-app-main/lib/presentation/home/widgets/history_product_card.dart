import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_food_delivery_user_app/core/constants/variables.dart';

import '../../../core/core.dart';
import '../../../data/models/response/order_history_response_model.dart';
import '../models/product_model.dart';

class HistoryProductCard extends StatelessWidget {
  final OrderItem item;
  const HistoryProductCard({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(8.0),
          child: CachedNetworkImage(
            imageUrl: '${Variables.baseUrl}/uploads/products/${item.product!.image}',
            fit: BoxFit.cover,
            width: 78.0,
            height: 78.0,
            placeholder: (context, url) =>
                const Center(child: CircularProgressIndicator()),
          ),
        ),
        const SpaceWidth(18.0),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              item.product!.name ?? '',
              style: const TextStyle(
                fontWeight: FontWeight.w700,
              ),
            ),
            const SpaceHeight(18.0),
            Text(
              '${item.product!.price!.currencyFormatRp} (${item.quantity})',
              style: const TextStyle(
                fontWeight: FontWeight.w500,
                color: AppColors.gray3,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
