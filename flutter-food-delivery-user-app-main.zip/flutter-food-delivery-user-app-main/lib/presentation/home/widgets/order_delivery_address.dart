import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/checkout/checkout_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/bloc/get_user/get_user_bloc.dart';
import 'package:flutter_food_delivery_user_app/presentation/home/pages/change_address_page.dart';

import '../../../core/core.dart';
import '../bloc/current_restaurant/current_restaurant_bloc.dart';

class OrderDeliveryAddress extends StatefulWidget {
  const OrderDeliveryAddress({super.key});

  @override
  State<OrderDeliveryAddress> createState() => _OrderDeliveryAddressState();
}

class _OrderDeliveryAddressState extends State<OrderDeliveryAddress> {
  String restaurantLatlong = '';
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(24.0),
        border: Border.all(color: AppColors.stroke),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Alamat Pengiriman',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),
              Button.outlined(
                onPressed: () {
                  context.push(const ChangeAddressPage());
                },
                label: 'Ubah',
                height: 30.0,
                width: 80.0,
                fontSize: 12.0,
                borderRadius: 32.0,
              ),
            ],
          ),
          const SpaceHeight(16.0),
          Row(
            children: [
              ClipOval(
                child: ColoredBox(
                  color: AppColors.background,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Assets.icons.location.svg(),
                  ),
                ),
              ),
              const SpaceWidth(8.0),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  BlocBuilder<CurrentRestaurantBloc, CurrentRestaurantState>(
                    builder: (context, state) {
                      state.maybeWhen(
                        orElse: () {},
                        success: (restaurant) {
                          restaurantLatlong = restaurant.latlong!;
                        },
                      );
                      return BlocBuilder<GetUserBloc, GetUserState>(
                        builder: (context, state) {
                          return state.maybeWhen(
                            orElse: () {
                              return const SizedBox();
                            },
                            loaded: (user) {
                              if (user.latlong != null &&
                                  user.latlong!.isNotEmpty) {
                                context.read<CheckoutBloc>().add(
                                      CheckoutEvent.updateDeliveryCost(
                                        restaurantLatlong,
                                        user.latlong!,
                                      ),
                                    );
                              }
                              return SizedBox(
                                width: 250,
                                child: Text(
                                  user.address ??
                                      'Alamat pengiriman belum tersedia. Silakan tambahkan alamat untuk melanjutkan.',
                                  style: TextStyle(
                                    fontWeight: user.address == null
                                        ? FontWeight.bold
                                        : FontWeight.w500,
                                    fontSize: 12.0,
                                    color: user.address == null
                                        ? AppColors.red
                                        : AppColors.gray3,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 3,
                                ),
                              );
                            },
                          );
                        },
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
