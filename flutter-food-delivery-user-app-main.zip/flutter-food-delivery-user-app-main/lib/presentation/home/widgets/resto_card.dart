import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_food_delivery_user_app/core/constants/variables.dart';
import 'package:flutter_food_delivery_user_app/data/models/response/all_restaurant_response_model.dart';

import '../../../core/core.dart';
import '../models/resto_model.dart';
import '../pages/resto_menu_page.dart';
// import '../pages/resto_menu_page.dart';

class RestoCard extends StatelessWidget {
  final Restaurant item;
  const RestoCard({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        context.push(RestoMenuPage(
          restaurant: item,
        ));
      }, // => context.push(const RestoMenuPage()),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12.0),
            child: CachedNetworkImage(
              width: context.deviceWidth,
              height: 94.0,
              fit: BoxFit.cover,
              imageUrl: '${Variables.imageUrl}${item.photo!}',
              placeholder: (context, url) =>
                  const Center(child: CircularProgressIndicator()),
            ),
          ),
          const SpaceHeight(8.0),
          Text(
            item.restaurantName!,
            style: const TextStyle(
              fontWeight: FontWeight.w600,
            ),
          ),
          Row(
            children: [
              Assets.icons.location.svg(
                width: 16.0,
                height: 16.0,
                colorFilter:
                    const ColorFilter.mode(AppColors.gray3, BlendMode.srcIn),
              ),
              const SpaceWidth(4.0),
              Flexible(
                // width: context.deviceWidth - 264.0,
                child: Text(
                  item.restaurantAddress ?? '',
                  // maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 12.0,
                    color: AppColors.gray3,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
