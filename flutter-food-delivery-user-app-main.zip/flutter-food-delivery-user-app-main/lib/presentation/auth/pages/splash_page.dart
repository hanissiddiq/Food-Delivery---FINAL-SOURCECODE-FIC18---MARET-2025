import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';


import '../../../core/core.dart';
import '../../../data/datasources/auth_local_datasource.dart';

import '../../home/pages/main_page.dart';
import 'login_page.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future: Future.delayed(
          const Duration(milliseconds: 2000),
          () => AuthLocalDatasource().isAuth(),
        ),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            if (snapshot.data == true) {
              return const MainPage();
            } else {
              return const LoginPage();
            }
          }
          return Scaffold(
            backgroundColor: AppColors.primary,
            body: Padding(
              padding: const EdgeInsets.all(48.0),
              child: Center(
                child: Assets.images.logo.image(),
              ),
            ),
            bottomNavigationBar: SizedBox(
              height: 100.0,
              child: Align(
                alignment: Alignment.center,
                child: Assets.images.logoCwb.image(width: 96.0),
              ),
            ),
          );
        },
      ),
    );
  }
}
