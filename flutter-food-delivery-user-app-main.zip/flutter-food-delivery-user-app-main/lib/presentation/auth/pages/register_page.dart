import 'dart:io';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_cropper/image_cropper.dart';

import 'package:image_picker/image_picker.dart';
import 'package:location/location.dart';
import 'package:geocoding/geocoding.dart' as geo;

import '../../../core/core.dart';
import '../../../data/models/request/register_request_model.dart';
import '../bloc/register/register_bloc.dart';
import 'login_page.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final nameController = TextEditingController();

  final passwordController = TextEditingController();

  final ImagePicker picker = ImagePicker();
  XFile? image;

  @override
  void initState() {
    // TODO: implement initState
    //798M+796, Kecamatan Ngaglik, 55581, Indonesia
    super.initState();
  }

  @override
  void dispose() {
    emailController.dispose();
    phoneController.dispose();
    nameController.dispose();
    passwordController.dispose();

    super.dispose();
  }

  Future<void> pickImage() async {
    final pickedImage = await picker.pickImage(source: ImageSource.gallery);
    if (pickedImage != null) {
      image = pickedImage;
    }

    if (image != null) {
      final CroppedFile? croppedImage = await cropImages(image!);
      if (croppedImage != null) {
        setState(() {
          image = XFile(croppedImage.path);
        });
      }
    }
  }

  Future<CroppedFile?> cropImages(XFile image) async {
    final croppedFile = await ImageCropper().cropImage(
      sourcePath: image.path,
      uiSettings: [
        AndroidUiSettings(
            toolbarTitle: 'Crop Image',
            toolbarColor: AppColors.primary,
            toolbarWidgetColor: Colors.white,
            initAspectRatio: CropAspectRatioPreset.original,
            statusBarColor: AppColors.primary,
            activeControlsWidgetColor: AppColors.primary,
            lockAspectRatio: true,
            aspectRatioPresets: [
              CropAspectRatioPreset.square,
            ]),
        IOSUiSettings(
          title: 'Crop Image',
        )
      ],
    );
    return croppedFile;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primary,
      body: Align(
        alignment: Alignment.bottomCenter,
        child: SingleChildScrollView(
          child: Stack(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 18.0, vertical: 30.0),
                margin: const EdgeInsets.only(top: 50.0),
                decoration: const BoxDecoration(
                  color: AppColors.white,
                  borderRadius:
                      BorderRadius.vertical(top: Radius.circular(28.0)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Sign Up',
                      style: TextStyle(
                        fontSize: 28.0,
                        fontWeight: FontWeight.bold,
                        color: AppColors.primary,
                      ),
                    ),
                    const SpaceHeight(28.0),
                    CustomTextField(
                      controller: nameController,
                      label: 'Name',
                      textInputAction: TextInputAction.next,
                      textCapitalization: TextCapitalization.words,
                      prefixIcon: const Icon(
                        Icons.person,
                        color: AppColors.primary,
                      ),
                    ),
                    const SpaceHeight(18.0),
                    CustomTextField(
                      controller: emailController,
                      label: 'Email',
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      isEmailTextField: true,
                      prefixIcon: const Icon(
                        Icons.email,
                        color: AppColors.primary,
                      ),
                    ),
                    const SpaceHeight(14.0),
                    CustomTextField(
                      controller: phoneController,
                      label: 'Handphone',
                      keyboardType: TextInputType.phone,
                      textInputAction: TextInputAction.next,
                      inputFormatter: [FilteringTextInputFormatter.digitsOnly],
                      prefixIcon: const Icon(
                        Icons.phone,
                        color: AppColors.primary,
                      ),
                    ),
                    const SpaceHeight(14.0),
                    CustomTextField(
                      controller: passwordController,
                      label: 'Password',
                      obscureText: true,
                      textInputAction: TextInputAction.next,
                      prefixIcon: const Icon(
                        Icons.key,
                        color: AppColors.primary,
                      ),
                    ),
                    const SpaceHeight(18.0),
                    const SpaceHeight(33.0),
                    BlocListener<RegisterBloc, RegisterState>(
                      listener: (context, state) {
                        state.maybeWhen(
                          orElse: () {},
                          success: (data) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Registration Success'),
                                backgroundColor: AppColors.primary,
                              ),
                            );
                            context.pushReplacement(const LoginPage());
                          },
                          error: (message) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('Register failed: $message'),
                                backgroundColor: AppColors.red,
                              ),
                            );
                          },
                        );
                      },
                      child: BlocBuilder<RegisterBloc, RegisterState>(
                        builder: (context, state) {
                          return state.maybeWhen(
                            orElse: () {
                              return Button.filled(
                                onPressed: () {
                                  if (image == null) {
                                    debugPrint("Image null: $image");
                                    context.showDialogError(
                                        'Failed', 'Foto profil belum dipilih');
                                  } else if (nameController.text.isEmpty ||
                                      emailController.text.isEmpty ||
                                      phoneController.text.isEmpty ||
                                      passwordController.text.isEmpty) {
                                    debugPrint("Image not null: $image");
                                    context.showDialogError('Failed',
                                        'Terdapat inputan yang masih kosong');
                                  } else {
                                    final RegisterRequestModel request =
                                        RegisterRequestModel(
                                      name: nameController.text,
                                      email: emailController.text,
                                      password: passwordController.text,
                                      phone: phoneController.text,
                                      photo: image,
                                    );

                                    context
                                        .read<RegisterBloc>()
                                        .add(RegisterEvent.register(
                                          requestModel: request,
                                        ));
                                  }
                                },
                                label: 'Sign Up',
                              );
                            },
                            loading: () {
                              return const Center(
                                child: CircularProgressIndicator(),
                              );
                            },
                          );
                        },
                      ),
                    ),
                    const SpaceHeight(16.0),
                    Center(
                      child: Text.rich(
                        TextSpan(
                          text: 'Sudah memiliki akun? ',
                          style: const TextStyle(
                            fontSize: 16.0,
                            color: AppColors.gray3,
                          ),
                          children: [
                            TextSpan(
                              text: 'Login',
                              style: const TextStyle(
                                color: AppColors.primary,
                              ),
                              recognizer: TapGestureRecognizer()
                                ..onTap = () => context.pop(),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Align(
                alignment: Alignment.topCenter,
                child: InkWell(
                  onTap: () {
                    pickImage();
                  },
                  child: ClipOval(
                    child: ColoredBox(
                      color: AppColors.gray5,
                      child: image != null
                          ? Image.file(
                              File(image!.path),
                              width: 100,
                              height: 100,
                              fit: BoxFit.cover,
                            )
                          : const Padding(
                              padding: EdgeInsets.all(35.0),
                              child: Icon(
                                Icons.camera_enhance_rounded,
                                size: 25,
                              ),
                            ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
