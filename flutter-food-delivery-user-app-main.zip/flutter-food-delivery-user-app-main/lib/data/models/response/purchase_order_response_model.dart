import 'dart:convert';

class PurchaseOrderResponseModel {
    final String? message;
    final Order? order;
    final Payment? payment;

    PurchaseOrderResponseModel({
        this.message,
        this.order,
        this.payment,
    });

    factory PurchaseOrderResponseModel.fromJson(String str) => PurchaseOrderResponseModel.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory PurchaseOrderResponseModel.fromMap(Map<String, dynamic> json) => PurchaseOrderResponseModel(
        message: json["message"],
        order: json["order"] == null ? null : Order.fromMap(json["order"]),
        payment: json["payment"] == null ? null : Payment.fromMap(json["payment"]),
    );

    Map<String, dynamic> toMap() => {
        "message": message,
        "order": order?.toMap(),
        "payment": payment?.toMap(),
    };
}

class Order {
    final int? id;
    final int? userId;
    final int? restaurantId;
    final dynamic driverId;
    final int? totalPrice;
    final int? shippingCost;
    final int? totalBill;
    final String? paymentMethod;
    final String? status;
    final dynamic shippingAddress;
    final String? shippingLatlong;
    final DateTime? createdAt;
    final DateTime? updatedAt;

    Order({
        this.id,
        this.userId,
        this.restaurantId,
        this.driverId,
        this.totalPrice,
        this.shippingCost,
        this.totalBill,
        this.paymentMethod,
        this.status,
        this.shippingAddress,
        this.shippingLatlong,
        this.createdAt,
        this.updatedAt,
    });

    factory Order.fromJson(String str) => Order.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory Order.fromMap(Map<String, dynamic> json) => Order(
        id: json["id"],
        userId: json["user_id"],
        restaurantId: json["restaurant_id"],
        driverId: json["driver_id"],
        totalPrice: json["total_price"],
        shippingCost: json["shipping_cost"],
        totalBill: json["total_bill"],
        paymentMethod: json["payment_method"],
        status: json["status"],
        shippingAddress: json["shipping_address"],
        shippingLatlong: json["shipping_latlong"],
        createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    );

    Map<String, dynamic> toMap() => {
        "id": id,
        "user_id": userId,
        "restaurant_id": restaurantId,
        "driver_id": driverId,
        "total_price": totalPrice,
        "shipping_cost": shippingCost,
        "total_bill": totalBill,
        "payment_method": paymentMethod,
        "status": status,
        "shipping_address": shippingAddress,
        "shipping_latlong": shippingLatlong,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
    };
}

class Payment {
    final String? id;
    final DateTime? created;
    final DateTime? updated;
    final String? referenceId;
    final String? businessId;
    final dynamic customerId;
    final dynamic customer;
    final int? amount;
    final dynamic minAmount;
    final dynamic maxAmount;
    final String? country;
    final String? currency;
    final PaymentMethod? paymentMethod;
    final dynamic description;
    final dynamic failureCode;
    final String? captureMethod;
    final dynamic initiator;
    final dynamic cardVerificationResults;
    final String? status;
    final List<Action>? actions;
    final dynamic metadata;
    final dynamic shippingInformation;
    final dynamic items;

    Payment({
        this.id,
        this.created,
        this.updated,
        this.referenceId,
        this.businessId,
        this.customerId,
        this.customer,
        this.amount,
        this.minAmount,
        this.maxAmount,
        this.country,
        this.currency,
        this.paymentMethod,
        this.description,
        this.failureCode,
        this.captureMethod,
        this.initiator,
        this.cardVerificationResults,
        this.status,
        this.actions,
        this.metadata,
        this.shippingInformation,
        this.items,
    });

    factory Payment.fromJson(String str) => Payment.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory Payment.fromMap(Map<String, dynamic> json) => Payment(
        id: json["id"],
        created: json["created"] == null ? null : DateTime.parse(json["created"]),
        updated: json["updated"] == null ? null : DateTime.parse(json["updated"]),
        referenceId: json["reference_id"],
        businessId: json["business_id"],
        customerId: json["customer_id"],
        customer: json["customer"],
        amount: json["amount"],
        minAmount: json["min_amount"],
        maxAmount: json["max_amount"],
        country: json["country"],
        currency: json["currency"],
        paymentMethod: json["payment_method"] == null ? null : PaymentMethod.fromMap(json["payment_method"]),
        description: json["description"],
        failureCode: json["failure_code"],
        captureMethod: json["capture_method"],
        initiator: json["initiator"],
        cardVerificationResults: json["card_verification_results"],
        status: json["status"],
        actions: json["actions"] == null ? [] : List<Action>.from(json["actions"]!.map((x) => Action.fromMap(x))),
        metadata: json["metadata"],
        shippingInformation: json["shipping_information"],
        items: json["items"],
    );

    Map<String, dynamic> toMap() => {
        "id": id,
        "created": created?.toIso8601String(),
        "updated": updated?.toIso8601String(),
        "reference_id": referenceId,
        "business_id": businessId,
        "customer_id": customerId,
        "customer": customer,
        "amount": amount,
        "min_amount": minAmount,
        "max_amount": maxAmount,
        "country": country,
        "currency": currency,
        "payment_method": paymentMethod?.toMap(),
        "description": description,
        "failure_code": failureCode,
        "capture_method": captureMethod,
        "initiator": initiator,
        "card_verification_results": cardVerificationResults,
        "status": status,
        "actions": actions == null ? [] : List<dynamic>.from(actions!.map((x) => x.toMap())),
        "metadata": metadata,
        "shipping_information": shippingInformation,
        "items": items,
    };
}

class Action {
    final String? action;
    final String? urlType;
    final String? method;
    final String? url;
    final dynamic qrCode;

    Action({
        this.action,
        this.urlType,
        this.method,
        this.url,
        this.qrCode,
    });

    factory Action.fromJson(String str) => Action.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory Action.fromMap(Map<String, dynamic> json) => Action(
        action: json["action"],
        urlType: json["url_type"],
        method: json["method"],
        url: json["url"],
        qrCode: json["qr_code"],
    );

    Map<String, dynamic> toMap() => {
        "action": action,
        "url_type": urlType,
        "method": method,
        "url": url,
        "qr_code": qrCode,
    };
}

class PaymentMethod {
    final String? id;
    final String? type;
    final DateTime? created;
    final DateTime? updated;
    final dynamic description;
    final String? referenceId;
    final dynamic card;
    final dynamic directDebit;
    final Ewallet? ewallet;
    final dynamic overTheCounter;
    final dynamic virtualAccount;
    final dynamic qrCode;
    final String? reusability;
    final String? status;
    final dynamic metadata;

    PaymentMethod({
        this.id,
        this.type,
        this.created,
        this.updated,
        this.description,
        this.referenceId,
        this.card,
        this.directDebit,
        this.ewallet,
        this.overTheCounter,
        this.virtualAccount,
        this.qrCode,
        this.reusability,
        this.status,
        this.metadata,
    });

    factory PaymentMethod.fromJson(String str) => PaymentMethod.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory PaymentMethod.fromMap(Map<String, dynamic> json) => PaymentMethod(
        id: json["id"],
        type: json["type"],
        created: json["created"] == null ? null : DateTime.parse(json["created"]),
        updated: json["updated"] == null ? null : DateTime.parse(json["updated"]),
        description: json["description"],
        referenceId: json["reference_id"],
        card: json["card"],
        directDebit: json["direct_debit"],
        ewallet: json["ewallet"] == null ? null : Ewallet.fromMap(json["ewallet"]),
        overTheCounter: json["over_the_counter"],
        virtualAccount: json["virtual_account"],
        qrCode: json["qr_code"],
        reusability: json["reusability"],
        status: json["status"],
        metadata: json["metadata"],
    );

    Map<String, dynamic> toMap() => {
        "id": id,
        "type": type,
        "created": created?.toIso8601String(),
        "updated": updated?.toIso8601String(),
        "description": description,
        "reference_id": referenceId,
        "card": card,
        "direct_debit": directDebit,
        "ewallet": ewallet?.toMap(),
        "over_the_counter": overTheCounter,
        "virtual_account": virtualAccount,
        "qr_code": qrCode,
        "reusability": reusability,
        "status": status,
        "metadata": metadata,
    };
}

class Ewallet {
    final String? channelCode;
    final ChannelProperties? channelProperties;
    final Account? account;

    Ewallet({
        this.channelCode,
        this.channelProperties,
        this.account,
    });

    factory Ewallet.fromJson(String str) => Ewallet.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory Ewallet.fromMap(Map<String, dynamic> json) => Ewallet(
        channelCode: json["channel_code"],
        channelProperties: json["channel_properties"] == null ? null : ChannelProperties.fromMap(json["channel_properties"]),
        account: json["account"] == null ? null : Account.fromMap(json["account"]),
    );

    Map<String, dynamic> toMap() => {
        "channel_code": channelCode,
        "channel_properties": channelProperties?.toMap(),
        "account": account?.toMap(),
    };
}

class Account {
    final dynamic name;
    final dynamic accountDetails;
    final dynamic balance;
    final dynamic pointBalance;

    Account({
        this.name,
        this.accountDetails,
        this.balance,
        this.pointBalance,
    });

    factory Account.fromJson(String str) => Account.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory Account.fromMap(Map<String, dynamic> json) => Account(
        name: json["name"],
        accountDetails: json["account_details"],
        balance: json["balance"],
        pointBalance: json["point_balance"],
    );

    Map<String, dynamic> toMap() => {
        "name": name,
        "account_details": accountDetails,
        "balance": balance,
        "point_balance": pointBalance,
    };
}

class ChannelProperties {
    final String? successReturnUrl;
    final String? failureReturnUrl;

    ChannelProperties({
        this.successReturnUrl,
        this.failureReturnUrl,
    });

    factory ChannelProperties.fromJson(String str) => ChannelProperties.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory ChannelProperties.fromMap(Map<String, dynamic> json) => ChannelProperties(
        successReturnUrl: json["success_return_url"],
        failureReturnUrl: json["failure_return_url"],
    );

    Map<String, dynamic> toMap() => {
        "success_return_url": successReturnUrl,
        "failure_return_url": failureReturnUrl,
    };
}
