import 'dart:convert';

class OrderResponseModel {
    final String? status;
    final String? message;
    final Data? data;

    OrderResponseModel({
        this.status,
        this.message,
        this.data,
    });

    factory OrderResponseModel.fromJson(String str) => OrderResponseModel.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory OrderResponseModel.fromMap(Map<String, dynamic> json) => OrderResponseModel(
        status: json["status"],
        message: json["message"],
        data: json["data"] == null ? null : Data.fromMap(json["data"]),
    );

    Map<String, dynamic> toMap() => {
        "status": status,
        "message": message,
        "data": data?.toMap(),
    };
}

class Data {
    final int? restaurantId;
    final int? shippingCost;
    final int? userId;
    final dynamic shippingAddress;
    final String? shippingLatlong;
    final String? status;
    final int? totalPrice;
    final int? totalBill;
    final DateTime? updatedAt;
    final DateTime? createdAt;
    final int? id;

    Data({
        this.restaurantId,
        this.shippingCost,
        this.userId,
        this.shippingAddress,
        this.shippingLatlong,
        this.status,
        this.totalPrice,
        this.totalBill,
        this.updatedAt,
        this.createdAt,
        this.id,
    });

    factory Data.fromJson(String str) => Data.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory Data.fromMap(Map<String, dynamic> json) => Data(
        restaurantId: json["restaurant_id"],
        shippingCost: json["shipping_cost"],
        userId: json["user_id"],
        shippingAddress: json["shipping_address"],
        shippingLatlong: json["shipping_latlong"],
        status: json["status"],
        totalPrice: json["total_price"],
        totalBill: json["total_bill"],
        updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
        createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
        id: json["id"],
    );

    Map<String, dynamic> toMap() => {
        "restaurant_id": restaurantId,
        "shipping_cost": shippingCost,
        "user_id": userId,
        "shipping_address": shippingAddress,
        "shipping_latlong": shippingLatlong,
        "status": status,
        "total_price": totalPrice,
        "total_bill": totalBill,
        "updated_at": updatedAt?.toIso8601String(),
        "created_at": createdAt?.toIso8601String(),
        "id": id,
    };
}
