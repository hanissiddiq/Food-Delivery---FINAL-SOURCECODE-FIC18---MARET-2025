import 'dart:convert';

class OrderHistoryResponseModel {
  final String? status;
  final String? message;
  final List<OrderHistory>? data;

  OrderHistoryResponseModel({
    this.status,
    this.message,
    this.data,
  });

  factory OrderHistoryResponseModel.fromJson(String str) =>
      OrderHistoryResponseModel.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory OrderHistoryResponseModel.fromMap(Map<String, dynamic> json) =>
      OrderHistoryResponseModel(
        status: json["status"],
        message: json["message"],
        data: json["data"] == null
            ? []
            : List<OrderHistory>.from(
                json["data"]!.map((x) => OrderHistory.fromMap(x))),
      );

  Map<String, dynamic> toMap() => {
        "status": status,
        "message": message,
        "data":
            data == null ? [] : List<dynamic>.from(data!.map((x) => x.toMap())),
      };
}

class OrderHistory {
  final int? id;
  final int? userId;
  final int? restaurantId;
  final dynamic driverId;
  final int? totalPrice;
  final int? shippingCost;
  final int? totalBill;
  final String? paymentMethod;
  final String? status;
  final String? shippingAddress;
  final String? shippingLatlong;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final Restaurant? user;
  final Restaurant? restaurant;
  final List<OrderItem>? orderItems;

  OrderHistory({
    this.id,
    this.userId,
    this.restaurantId,
    this.driverId,
    this.totalPrice,
    this.shippingCost,
    this.totalBill,
    this.paymentMethod,
    this.status,
    this.shippingAddress,
    this.shippingLatlong,
    this.createdAt,
    this.updatedAt,
    this.user,
    this.restaurant,
    this.orderItems,
  });

  factory OrderHistory.fromJson(String str) =>
      OrderHistory.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory OrderHistory.fromMap(Map<String, dynamic> json) => OrderHistory(
        id: json["id"],
        userId: json["user_id"],
        restaurantId: json["restaurant_id"],
        driverId: json["driver_id"],
        totalPrice: json["total_price"],
        shippingCost: json["shipping_cost"],
        totalBill: json["total_bill"],
        paymentMethod: json["payment_method"],
        status: json["status"],
        shippingAddress: json["shipping_address"],
        shippingLatlong: json["shipping_latlong"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        user: json["user"] == null ? null : Restaurant.fromMap(json["user"]),
        restaurant: json["restaurant"] == null
            ? null
            : Restaurant.fromMap(json["restaurant"]),
        orderItems: json["order_items"] == null
            ? []
            : List<OrderItem>.from(
                json["order_items"]!.map((x) => OrderItem.fromMap(x))),
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "user_id": userId,
        "restaurant_id": restaurantId,
        "driver_id": driverId,
        "total_price": totalPrice,
        "shipping_cost": shippingCost,
        "total_bill": totalBill,
        "payment_method": paymentMethod,
        "status": status,
        "shipping_address": shippingAddress,
        "shipping_latlong": shippingLatlong,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "user": user?.toMap(),
        "restaurant": restaurant?.toMap(),
        "order_items": orderItems == null
            ? []
            : List<dynamic>.from(orderItems!.map((x) => x.toMap())),
      };
}

class OrderItem {
  final int? id;
  final int? orderId;
  final int? productId;
  final int? quantity;
  final int? price;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final Product? product;

  OrderItem({
    this.id,
    this.orderId,
    this.productId,
    this.quantity,
    this.price,
    this.createdAt,
    this.updatedAt,
    this.product,
  });

  factory OrderItem.fromJson(String str) => OrderItem.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory OrderItem.fromMap(Map<String, dynamic> json) => OrderItem(
        id: json["id"],
        orderId: json["order_id"],
        productId: json["product_id"],
        quantity: json["quantity"],
        price: json["price"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        product:
            json["product"] == null ? null : Product.fromMap(json["product"]),
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "order_id": orderId,
        "product_id": productId,
        "quantity": quantity,
        "price": price,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "product": product?.toMap(),
      };
}

class Product {
  final int? id;
  final String? name;
  final String? description;
  final int? price;
  final int? stock;
  final int? isAvailable;
  final int? isFavorite;
  final String? image;
  final int? userId;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  Product({
    this.id,
    this.name,
    this.description,
    this.price,
    this.stock,
    this.isAvailable,
    this.isFavorite,
    this.image,
    this.userId,
    this.createdAt,
    this.updatedAt,
  });

  factory Product.fromJson(String str) => Product.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory Product.fromMap(Map<String, dynamic> json) => Product(
        id: json["id"],
        name: json["name"],
        description: json["description"],
        price: json["price"],
        stock: json["stock"],
        isAvailable: json["is_available"],
        isFavorite: json["is_favorite"],
        image: json["image"],
        userId: json["user_id"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "name": name,
        "description": description,
        "price": price,
        "stock": stock,
        "is_available": isAvailable,
        "is_favorite": isFavorite,
        "image": image,
        "user_id": userId,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
      };
}

class Restaurant {
  final int? id;
  final String? name;
  final String? email;
  final dynamic emailVerifiedAt;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final String? phone;
  final String? address;
  final String? roles;
  final dynamic licensePlate;
  final String? restaurantName;
  final String? restaurantAddress;
  final String? photo;
  final String? latlong;
  final String? fcmId;

  Restaurant({
    this.id,
    this.name,
    this.email,
    this.emailVerifiedAt,
    this.createdAt,
    this.updatedAt,
    this.phone,
    this.address,
    this.roles,
    this.licensePlate,
    this.restaurantName,
    this.restaurantAddress,
    this.photo,
    this.latlong,
    this.fcmId,
  });

  factory Restaurant.fromJson(String str) =>
      Restaurant.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory Restaurant.fromMap(Map<String, dynamic> json) => Restaurant(
        id: json["id"],
        name: json["name"],
        email: json["email"],
        emailVerifiedAt: json["email_verified_at"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        phone: json["phone"],
        address: json["address"],
        roles: json["roles"],
        licensePlate: json["license_plate"],
        restaurantName: json["restaurant_name"],
        restaurantAddress: json["restaurant_address"],
        photo: json["photo"],
        latlong: json["latlong"],
        fcmId: json["fcm_id"],
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "name": name,
        "email": email,
        "email_verified_at": emailVerifiedAt,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "phone": phone,
        "address": address,
        "roles": roles,
        "license_plate": licensePlate,
        "restaurant_name": restaurantName,
        "restaurant_address": restaurantAddress,
        "photo": photo,
        "latlong": latlong,
        "fcm_id": fcmId,
      };
}
