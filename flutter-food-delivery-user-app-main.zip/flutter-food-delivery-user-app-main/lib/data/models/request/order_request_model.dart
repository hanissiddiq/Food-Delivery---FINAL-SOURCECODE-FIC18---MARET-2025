import 'dart:convert';

class OrderRequestModel {
    final int restaurantId;
    final int shippingCost;
    final List<OrderItem> orderItems;

    OrderRequestModel({
        required this.restaurantId,
        required this.shippingCost,
        required this.orderItems,
    });

    factory OrderRequestModel.fromJson(String str) => OrderRequestModel.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory OrderRequestModel.fromMap(Map<String, dynamic> json) => OrderRequestModel(
        restaurantId: json["restaurant_id"],
        shippingCost: json["shipping_cost"],
        orderItems: List<OrderItem>.from(json["order_items"].map((x) => OrderItem.fromMap(x))),
    );

    Map<String, dynamic> toMap() => {
        "restaurant_id": restaurantId,
        "shipping_cost": shippingCost,
        "order_items": List<dynamic>.from(orderItems.map((x) => x.toMap())),
    };
}

class OrderItem {
    final int productId;
    final int quantity;

    OrderItem({
        required this.productId,
        required this.quantity,
    });

    factory OrderItem.fromJson(String str) => OrderItem.fromMap(json.decode(str));

    String toJson() => json.encode(toMap());

    factory OrderItem.fromMap(Map<String, dynamic> json) => OrderItem(
        productId: json["product_id"],
        quantity: json["quantity"],
    );

    Map<String, dynamic> toMap() => {
        "product_id": productId,
        "quantity": quantity,
    };
}
