import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:flutter_food_delivery_user_app/data/models/request/order_request_model.dart';
import 'package:flutter_food_delivery_user_app/data/models/response/order_history_response_model.dart';
import 'package:flutter_food_delivery_user_app/data/models/response/order_response_model.dart';
import 'package:flutter_food_delivery_user_app/data/models/response/purchase_order_response_model.dart';
import 'package:http/http.dart' as http;

import '../../core/constants/variables.dart';
import 'auth_local_datasource.dart';

class OrderRemoteDatasource {
  Future<Either<String, OrderResponseModel>> order(
      OrderRequestModel data) async {
    final authData = await AuthLocalDatasource().getAuthData();
    final Map<String, String> headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${authData.data!.token}',
    };

    final url = Uri.parse('${Variables.baseUrl}/api/order');
    final response = await http.post(
      url,
      headers: headers,
      body: data.toJson(),
    );

    if (response.statusCode == 201) {
      return Right(OrderResponseModel.fromJson(response.body));
    } else {
      return Left(response.body);
    }
  }

  Future<Either<String, PurchaseOrderResponseModel>> purchase(
    String walletName,
    int orderId,
  ) async {
    final authData = await AuthLocalDatasource().getAuthData();
    final Map<String, String> headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${authData.data!.token}',
    };

    final url = Uri.parse('${Variables.baseUrl}/api/purchase/$orderId');
    final response = await http.post(
      url,
      headers: headers,
      body: jsonEncode({
        'payment_method': 'e_wallet',
        'payment_e_wallet': walletName,
      }),
    );

    if (response.statusCode == 200) {
      return Right(PurchaseOrderResponseModel.fromJson(response.body));
    } else {
      return Left(response.body);
    }
  }

  Future<Either<String, String>> updateStatusOrder(
    int orderId,
    String status,
  ) async {
    final authData = await AuthLocalDatasource().getAuthData();
    final Map<String, String> headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${authData.data!.token}',
    };

    final url =
        Uri.parse('${Variables.baseUrl}/api/order/user/update-status/$orderId');
    final response = await http.put(
      url,
      headers: headers,
      body: jsonEncode({
        'status': status,
      }),
    );

    if (response.statusCode == 200) {
      return const Right('Success');
    } else {
      return Left(response.body);
    }
  }

  Future<Either<String, OrderHistoryResponseModel>> getOrderHistory() async {
    final authData = await AuthLocalDatasource().getAuthData();
    final Map<String, String> headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${authData.data!.token}',
    };

    final url = Uri.parse('${Variables.baseUrl}/api/order/user');
    final response = await http.get(
      url,
      headers: headers,
    );

    if (response.statusCode == 200) {
      return Right(OrderHistoryResponseModel.fromJson(response.body));
    } else {
      return Left(response.body);
    }
  }
}
