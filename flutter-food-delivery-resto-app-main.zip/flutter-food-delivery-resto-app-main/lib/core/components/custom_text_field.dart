import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../constants/colors.dart';
import 'spaces.dart';

class CustomTextField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final void Function(String value)? onChanged;
  final bool obscureText;
  final TextInputType? keyboardType;
  final TextCapitalization? textCapitalization;
  final bool showLabel;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final bool readOnly;
  final TextInputAction? textInputAction;
  final double borderRadius;
  final List<TextInputFormatter>? inputFormatter;
  final bool isEmailTextField;

  const CustomTextField({
    super.key,
    required this.controller,
    required this.label,
    this.onChanged,
    this.obscureText = false,
    this.keyboardType,
    this.showLabel = true,
    this.prefixIcon,
    this.suffixIcon,
    this.readOnly = false,
    this.textInputAction,
    this.borderRadius = 8.0,
    this.inputFormatter,
    this.isEmailTextField = false,
    this.textCapitalization,
  });

  @override
  _CustomTextFieldState createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextField> {
  String? errorMessage;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (widget.showLabel) ...[
          Text(
            widget.label,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SpaceHeight(12.0),
        ],
        TextFormField(
          controller: widget.controller,
          onChanged: (value) {
            if (widget.isEmailTextField) {
              if (!_isValidEmail(value)) {
                setState(() {
                  errorMessage = 'Please enter a valid email address';
                });
              } else {
                setState(() {
                  errorMessage = null;
                });
              }
            }

            if (widget.onChanged != null) {
              widget.onChanged!(value);
            }
          },
          obscureText: widget.obscureText,
          keyboardType: widget.isEmailTextField
              ? TextInputType.emailAddress
              : widget.keyboardType,
          textInputAction: widget.textInputAction,
          readOnly: widget.readOnly,
          inputFormatters: widget.inputFormatter,
          textCapitalization: widget.textCapitalization ?? TextCapitalization.none,
          style: TextStyle(
            color: widget.readOnly ? Colors.grey : Colors.black,
          ),
          decoration: InputDecoration(
            prefixIcon: widget.prefixIcon,
            suffixIcon: widget.suffixIcon,
            filled: widget.readOnly,
            fillColor: widget.readOnly ? Colors.grey[200] : Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(widget.borderRadius),
              borderSide: BorderSide(
                color: errorMessage != null
                    ? Colors.red
                    : widget.readOnly
                        ? Colors.grey
                        : AppColors.stroke,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(widget.borderRadius),
              borderSide: BorderSide(
                color: errorMessage != null ? Colors.red : AppColors.stroke,
              ),
            ),
            hintText: widget.label,
            hintStyle: const TextStyle(
              color: Color.fromARGB(255, 91, 91, 91),
            ),
            errorText: errorMessage,
            errorStyle: const TextStyle(color: Colors.red),
          ),
        ),
      ],
    );
  }

  bool _isValidEmail(String email) {
    final emailRegex = RegExp(
      r'^[^@\s]+@[^@\s]+\.[^@\s]+$',
    );
    return emailRegex.hasMatch(email);
  }
}
