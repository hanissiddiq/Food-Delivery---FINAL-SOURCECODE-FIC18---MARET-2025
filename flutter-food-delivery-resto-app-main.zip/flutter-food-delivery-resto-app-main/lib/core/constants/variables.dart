class Variables {
  static const String appName = 'Flutter FIC18';
  static const String baseUrl = 'http://192.168.18.23:8000';
  static const String imageUrl = '$baseUrl/storage/';
}
