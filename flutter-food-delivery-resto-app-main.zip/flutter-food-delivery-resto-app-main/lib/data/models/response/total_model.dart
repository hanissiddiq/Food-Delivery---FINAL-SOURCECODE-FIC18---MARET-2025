// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class TotalModel {
  final String? status;
    final String? message;
    final int? data;

  TotalModel({required this.status, required this.message, required this.data});

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'status': status,
      'message': message,
      'data': data,
    };
  }

  factory TotalModel.fromMap(Map<String, dynamic> map) {
    return TotalModel(
      status: map['status'] != null ? map['status'] as String : null,
      message: map['message'] != null ? map['message'] as String : null,
      data: map['data'] != null ? map['data'] as int : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory TotalModel.fromJson(String source) => TotalModel.fromMap(json.decode(source) as Map<String, dynamic>);

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
  
    return other is TotalModel &&
      other.status == status &&
      other.message == message &&
      other.data == data;
  }

  @override
  int get hashCode => status.hashCode ^ message.hashCode ^ data.hashCode;
}
