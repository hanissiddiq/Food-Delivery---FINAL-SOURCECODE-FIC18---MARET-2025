import 'dart:developer';

import 'package:dartz/dartz.dart';
import 'package:flutter_food_delivery_resto_app/core/constants/variables.dart';
import 'package:flutter_food_delivery_resto_app/data/datasources/auth_local_datasource.dart';
import 'package:flutter_food_delivery_resto_app/data/models/response/total_model.dart';
import 'package:http/http.dart' as http;

class StatisticRemoteDatasource {
  Future<Either<String, TotalModel>> getTotalProduct() async {
    final authData = await AuthLocalDatasource().getAuthData();
    final header = {
      'Authorization': 'Bearer ${authData.data?.token}',
      'Accept': 'application/json',
    };

    final response = await http.get(
      Uri.parse('${Variables.baseUrl}/api/total/product'),
      headers: header,
    );

    if (response.statusCode == 200) {
      return Right(TotalModel.fromJson(response.body));
    } else {
      return Left(response.body);
    }
  }

  Future<Either<String, TotalModel>> getTotalOrder() async {
    final authData = await AuthLocalDatasource().getAuthData();
    final header = {
      'Authorization': 'Bearer ${authData.data?.token}',
      'Accept': 'application/json',
    };

    final response = await http.get(
      Uri.parse('${Variables.baseUrl}/api/total/order'),
      headers: header,
    );

    if (response.statusCode == 200) {
      return Right(TotalModel.fromJson(response.body));
    } else {
      return Left(response.body);
    }
  }

  Future<Either<String, TotalModel>> getTotalTodayTransaction() async {
    final authData = await AuthLocalDatasource().getAuthData();
    final header = {
      'Authorization': 'Bearer ${authData.data?.token}',
      'Accept': 'application/json',
    };

    final response = await http.get(
      Uri.parse('${Variables.baseUrl}/api/total/today-transaction'),
      headers: header,
    );

    if (response.statusCode == 200) {
      return Right(TotalModel.fromJson(response.body));
    } else {
      return Left(response.body);
    }
  }

  Future<Either<String, TotalModel>> getTotalIncome() async {
    final authData = await AuthLocalDatasource().getAuthData();
    final header = {
      'Authorization': 'Bearer ${authData.data?.token}',
      'Accept': 'application/json',
    };

    final response = await http.get(
      Uri.parse('${Variables.baseUrl}/api/total/income'),
      headers: header,
    );

    log('Response: ${response.body}');

    if (response.statusCode == 200) {
      return Right(TotalModel.fromJson(response.body));
    } else {
      return Left(response.body);
    }
  }
}
