import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:flutter_food_delivery_resto_app/core/constants/variables.dart';
import 'package:flutter_food_delivery_resto_app/data/models/response/order_history_response_model.dart';
import 'package:http/http.dart' as http;

import 'auth_local_datasource.dart';

class OrderRemoteDatasource {
  Future<Either<String, OrderHistoryResponseModel>> getOrder() async {
    final authData = await AuthLocalDatasource().getAuthData();
    final Map<String, String> headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${authData.data!.token}',
    };

    final url = Uri.parse('${Variables.baseUrl}/api/order/restaurant');
    final response = await http.get(
      url,
      headers: headers,
    );

    if (response.statusCode == 200) {
      return Right(OrderHistoryResponseModel.fromJson(response.body));
    } else {
      return Left(response.body);
    }
  }

  Future<Either<String, String>> updateStatusOrder(
    int orderId,
    String status,
  ) async {
    final authData = await AuthLocalDatasource().getAuthData();
    final Map<String, String> headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${authData.data!.token}',
    };

    final url =
        Uri.parse('${Variables.baseUrl}/api/order/restaurant/update-status/$orderId');
    final response = await http.put(
      url,
      headers: headers,
      body: jsonEncode({
        'status': status,
      }),
    );

    if (response.statusCode == 200) {
      return const Right('Success');
    } else {
      return Left(response.body);
    }
  }
}
