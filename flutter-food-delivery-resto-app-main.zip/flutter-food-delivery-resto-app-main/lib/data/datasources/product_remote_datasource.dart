import 'package:dartz/dartz.dart';
import 'package:flutter_food_delivery_resto_app/core/constants/variables.dart';
import 'package:flutter_food_delivery_resto_app/data/models/request/product_request_model.dart';
import 'package:flutter_food_delivery_resto_app/data/models/response/product_response_modeld.dart';
import 'package:http/http.dart' as http;

import '../models/response/products_response_model.dart';
import 'auth_local_datasource.dart';

class ProductRemoteDatasource {
  Future<Either<String, ProductResponseModel>> addProduct(
      ProductRequestModel data) async {
    final authData = await AuthLocalDatasource().getAuthData();
    final header = {
      'Authorization': 'Bearer ${authData.data?.token}',
      'Accept': 'application/json',
    };

    var request = http.MultipartRequest(
      'POST',
      Uri.parse('${Variables.baseUrl}/api/products'),
    );

    request.fields.addAll(data.toMap());
    request.files.add(
      await http.MultipartFile.fromPath(
        'image',
        data.image!.path,
      ),
    );
    request.headers.addAll(header);

    http.StreamedResponse response = await request.send();

    final String body = await response.stream.bytesToString();

    if (response.statusCode == 201) {
      return Right(ProductResponseModel.fromJson(body));
    } else {
      return Left(body);
    }
  }

  Future<Either<String, ProductsResponseModel>> getProducts() async {
    final authData = await AuthLocalDatasource().getAuthData();
    final header = {
      'Authorization': 'Bearer ${authData.data?.token}',
      'Accept': 'application/json',
    };

    final response = await http.get(
      Uri.parse('${Variables.baseUrl}/api/products'),
      headers: header,
    );

    if (response.statusCode == 200) {
      return Right(ProductsResponseModel.fromJson(response.body));
    } else {
      return Left(response.body);
    }
  }

  Future<Either<String, String>> deleteProduct(int id) async {
    final authData = await AuthLocalDatasource().getAuthData();
    final header = {
      'Authorization': 'Bearer ${authData.data?.token}',
      'Accept': 'application/json',
    };

    final response = await http.delete(
      Uri.parse('${Variables.baseUrl}/api/products/$id'),
      headers: header,
    );

    if (response.statusCode == 200) {
      return const Right('Success');
    } else {
      return Left(response.body);
    }
  }

  Future<Either<String, ProductResponseModel>> updateProduct(
      ProductRequestModel data, int id) async {
    final authData = await AuthLocalDatasource().getAuthData();
    final header = {
      'Authorization': 'Bearer ${authData.data?.token}',
      'Accept': 'application/json',
      'Content-Type': 'application/json',
    };

    final response = await http.put(
      Uri.parse('${Variables.baseUrl}/api/products/$id'),
      headers: header,
      body: data.toJson(),
    );

    if (response.statusCode == 200) {
      return Right(ProductResponseModel.fromJson(response.body));
    } else {
      return Left(response.body);
    }

    // var request = http.MultipartRequest(
    //   'POST',
    //   Uri.parse('${Variables.baseUrl}/api/products/$id'),
    // );

    // request.fields.addAll(data.toMap());
    // request.files.add(
    //   await http.MultipartFile.fromPath(
    //     'image',
    //     data.image.path,
    //   ),
    // );
    // request.headers.addAll(header);

    // http.StreamedResponse response = await request.send();

    // final String body = await response.stream.bytesToString();

    // if (response.statusCode == 200) {
    //   return Right(ProductResponseModel.fromJson(body));
    // } else {
    //   return Left(body);
    // }
  }
}
