import 'dart:convert';
import 'dart:io';

import 'package:dartz/dartz.dart';
import 'package:flutter_food_delivery_resto_app/core/constants/variables.dart';
import 'package:flutter_food_delivery_resto_app/data/datasources/auth_local_datasource.dart';
import 'package:flutter_food_delivery_resto_app/data/models/request/register_request_model.dart';
import 'package:flutter_food_delivery_resto_app/data/models/response/auth_response_model.dart';
import 'package:flutter_food_delivery_resto_app/data/models/response/register_response_model.dart';
import 'package:http/http.dart' as http;

class AuthRemoteDatasource {
  Future<Either<String, RegisterResponseModel>> register(
      RegisterRequestModel requestModel) async {
    final Map<String, String> headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    final url = Uri.parse('${Variables.baseUrl}/api/restaurant/register');
    var request = http.MultipartRequest('POST', url);

    try {
      request.files.add(
        await http.MultipartFile.fromPath('photo', requestModel.photo!.path),
      );
      request.fields.addAll(requestModel.toMap());
      request.headers.addAll(headers);

      http.StreamedResponse response = await request.send();

      final String body = await response.stream.bytesToString();

      if (response.statusCode == 201) {
        return Right(RegisterResponseModel.fromJson(body));
      } else {
        return Left(RegisterResponseModel.fromJson(body).message!);
      }
    } catch (e) {
      if (e is SocketException) {
        return const Left('Tidak ada koneksi jaringan. Cek jaringan Anda.');
      } else {
        return Left('Terjadi kesalahan: $e');
      }
    }
  }

  Future<Either<String, AuthResponseModel>> login(
    String email,
    String password,
  ) async {
    final header = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    final url = Uri.parse('${Variables.baseUrl}/api/login');
    final response = await http.post(
      url,
      body: jsonEncode(
        {'email': email, 'password': password},
      ),
      headers: header,
    );

    if (response.statusCode == 200) {
      return Right(AuthResponseModel.fromJson(response.body));
    } else {
      return Left(response.body);
    }
  }

  Future<Either<String, String>> logout() async {
    final authData = await AuthLocalDatasource().getAuthData();
    final header = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${authData.data!.token}',
    };

    final url = Uri.parse('${Variables.baseUrl}/api/logout');
    final response = await http.post(
      url,
      headers: header,
    );

    if (response.statusCode == 200) {
      return const Right('Logout success');
    } else {
      return Left(response.body);
    }
  }

  Future<Either<String, String>> updateFcmToken(String fcmToken) async {
    final authData = await AuthLocalDatasource().getAuthData();
    final header = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': 'Bearer ${authData.data!.token}',
    };

    final url = Uri.parse('${Variables.baseUrl}/api/user/update-fcm');
    final response = await http.put(
      url,
      headers: header,
      body: jsonEncode(
        {'fcm_id': fcmToken},
      ),
    );

    if (response.statusCode == 200) {
      return const Right('Update success');
    } else {
      return Left(response.body);
    }
  }
}
