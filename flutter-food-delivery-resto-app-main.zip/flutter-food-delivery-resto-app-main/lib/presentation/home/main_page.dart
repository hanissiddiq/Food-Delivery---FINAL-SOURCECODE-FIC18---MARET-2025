import 'package:flutter/material.dart';
import 'package:flutter_food_delivery_resto_app/core/core.dart';
import 'package:flutter_food_delivery_resto_app/data/datasources/firebase_messaging_remote_datasource.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/pages/profile_page.dart';

import '../menu/pages/home_page.dart';
import '../menu/pages/menu_page.dart';
import '../menu/pages/order_page.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _selectedIndex = 0;
  final _widgets = [
    const HomeRestoPage(),
    const MenuPage(),
    const OrderPage(),
    const ProfilePage(),
  ];

  @override
  void initState() {
    FirebaseMessagingRemoteDatasource().initialize();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: _widgets,
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.symmetric(vertical: 10.0),
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.stroke),
        ),
        child: Theme(
          data: ThemeData(
            splashColor: Colors.white,
            highlightColor: Colors.white,
          ),
          child: BottomNavigationBar(
            backgroundColor: AppColors.white,
            useLegacyColorScheme: false,
            currentIndex: _selectedIndex,
            onTap: (value) => setState(() => _selectedIndex = value),
            type: BottomNavigationBarType.fixed,
            selectedLabelStyle: const TextStyle(color: AppColors.primary),
            selectedIconTheme: const IconThemeData(color: AppColors.primary),
            elevation: 0,
            items: [
              BottomNavigationBarItem(
                icon: Assets.icons.nav.home.svg(
                  colorFilter: ColorFilter.mode(
                    _selectedIndex == 0
                        ? AppColors.primary
                        : AppColors.navPlaceholder,
                    BlendMode.srcIn,
                  ),
                ),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                icon: Assets.icons.nav.menu.svg(
                  colorFilter: ColorFilter.mode(
                    _selectedIndex == 1
                        ? AppColors.primary
                        : AppColors.navPlaceholder,
                    BlendMode.srcIn,
                  ),
                ),
                label: 'Menu',
              ),
              BottomNavigationBarItem(
                icon: Assets.icons.nav.order.svg(
                  colorFilter: ColorFilter.mode(
                    _selectedIndex == 2
                        ? AppColors.primary
                        : AppColors.navPlaceholder,
                    BlendMode.srcIn,
                  ),
                ),
                label: 'Pesanan',
              ),
              BottomNavigationBarItem(
                icon: Assets.icons.nav.profile.svg(
                  colorFilter: ColorFilter.mode(
                    _selectedIndex == 3
                        ? AppColors.primary
                        : AppColors.navPlaceholder,
                    BlendMode.srcIn,
                  ),
                ),
                label: 'Profile',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
