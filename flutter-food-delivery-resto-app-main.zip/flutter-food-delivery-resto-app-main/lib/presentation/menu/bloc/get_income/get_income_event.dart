part of 'get_income_bloc.dart';

@freezed
class GetIncomeEvent with _$GetIncomeEvent {
  const factory GetIncomeEvent.started() = _Started;
  const factory GetIncomeEvent.getIncome() = _GetIncome;
}