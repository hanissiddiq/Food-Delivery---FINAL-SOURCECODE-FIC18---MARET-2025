import 'dart:developer';

import 'package:bloc/bloc.dart';
import 'package:flutter_food_delivery_resto_app/data/datasources/statistic_remote_datasource.dart';
import 'package:flutter_food_delivery_resto_app/data/models/response/total_model.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'get_income_event.dart';
part 'get_income_state.dart';
part 'get_income_bloc.freezed.dart';

class GetIncomeBloc extends Bloc<GetIncomeEvent, GetIncomeState> {
  final StatisticRemoteDatasource datasource;
  GetIncomeBloc(this.datasource) : super(_Initial()) {
    on<_GetIncome>((event, emit) async {
      emit(const _Loading());
      final result = await datasource.getTotalIncome();
      result.fold(
        (error) => emit(_Error(error)),
        (data) => emit(_Success(data)),
      );
    });
  }
}
