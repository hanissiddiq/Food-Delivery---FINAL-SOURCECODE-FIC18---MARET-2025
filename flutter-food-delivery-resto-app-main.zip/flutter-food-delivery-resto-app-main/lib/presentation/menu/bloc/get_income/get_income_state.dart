part of 'get_income_bloc.dart';

@freezed
class GetIncomeState with _$GetIncomeState {
  const factory GetIncomeState.initial() = _Initial;
  const factory GetIncomeState.loading() = _Loading;
  const factory GetIncomeState.success(TotalModel data) = _Success;
  const factory GetIncomeState.error(String error) = _Error;
}
