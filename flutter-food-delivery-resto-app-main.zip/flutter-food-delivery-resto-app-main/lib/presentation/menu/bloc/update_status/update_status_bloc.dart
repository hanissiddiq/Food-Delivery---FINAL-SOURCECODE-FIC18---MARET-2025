import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../../../data/datasources/order_remote_datasource.dart';

part 'update_status_bloc.freezed.dart';
part 'update_status_event.dart';
part 'update_status_state.dart';

class UpdateStatusBloc extends Bloc<UpdateStatusEvent, UpdateStatusState> {
  final OrderRemoteDatasource datasource;
  UpdateStatusBloc(
    this.datasource,
  ) : super(const _Initial()) {
    on<_UpdateStatus>((event, emit) async {
      emit(const _Loading());
      final result = await datasource.updateStatusOrder(event.id, event.status);
      result.fold(
        (l) => emit(_Error(l)),
        (r) => emit(const _Loaded()),
      );
    });
  }
}
