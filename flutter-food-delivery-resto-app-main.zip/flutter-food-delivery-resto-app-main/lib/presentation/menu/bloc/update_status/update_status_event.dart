part of 'update_status_bloc.dart';

@freezed
class UpdateStatusEvent with _$UpdateStatusEvent {
  const factory UpdateStatusEvent.started() = _Started;
  const factory UpdateStatusEvent.updateStatus({
    required int id,
    required String status,
  }) = _UpdateStatus;
}