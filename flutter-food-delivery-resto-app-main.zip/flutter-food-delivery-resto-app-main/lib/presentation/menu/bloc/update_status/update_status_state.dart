part of 'update_status_bloc.dart';

@freezed
class UpdateStatusState with _$UpdateStatusState {
  const factory UpdateStatusState.initial() = _Initial;
  const factory UpdateStatusState.loading() = _Loading;
  const factory UpdateStatusState.loaded() = _Loaded;
  const factory UpdateStatusState.error(String message) = _Error;
}
