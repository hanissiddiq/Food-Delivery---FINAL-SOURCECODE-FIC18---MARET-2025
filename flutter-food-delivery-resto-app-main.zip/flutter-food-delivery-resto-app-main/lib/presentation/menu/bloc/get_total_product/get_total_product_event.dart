part of 'get_total_product_bloc.dart';

@freezed
class GetTotalProductEvent with _$GetTotalProductEvent {
  const factory GetTotalProductEvent.started() = _Started;

  const factory GetTotalProductEvent.getTotalProduct() = _GetTotalProduct;
}
