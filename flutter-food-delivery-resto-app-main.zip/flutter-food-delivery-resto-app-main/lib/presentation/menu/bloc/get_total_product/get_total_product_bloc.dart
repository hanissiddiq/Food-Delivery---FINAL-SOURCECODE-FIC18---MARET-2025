import 'package:bloc/bloc.dart';
import 'package:flutter_food_delivery_resto_app/data/datasources/statistic_remote_datasource.dart';
import 'package:flutter_food_delivery_resto_app/data/models/response/total_model.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'get_total_product_event.dart';
part 'get_total_product_state.dart';
part 'get_total_product_bloc.freezed.dart';

class GetTotalProductBloc
    extends Bloc<GetTotalProductEvent, GetTotalProductState> {
  final StatisticRemoteDatasource datasource;
  GetTotalProductBloc(this.datasource) : super(_Initial()) {
    on<_GetTotalProduct>((event, emit) async {
      emit(const _Loading());
      final result = await datasource.getTotalProduct();
      result.fold(
        (error) => emit(_Error(error)),
        (data) => emit(_Success(data)),
      );
    });
  }
}
