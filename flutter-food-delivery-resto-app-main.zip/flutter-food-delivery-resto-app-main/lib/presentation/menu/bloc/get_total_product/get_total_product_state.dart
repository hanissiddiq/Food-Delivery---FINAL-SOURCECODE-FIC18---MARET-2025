part of 'get_total_product_bloc.dart';

@freezed
class GetTotalProductState with _$GetTotalProductState {
  const factory GetTotalProductState.initial() = _Initial;
  const factory GetTotalProductState.loading() = _Loading;
  const factory GetTotalProductState.success(TotalModel data) = _Success;
  const factory GetTotalProductState.error(String data) = _Error;
}
