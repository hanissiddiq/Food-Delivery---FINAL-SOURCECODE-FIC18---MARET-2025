import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'package:flutter_food_delivery_resto_app/data/datasources/product_remote_datasource.dart';

import '../../../../data/models/request/product_request_model.dart';

part 'add_product_bloc.freezed.dart';
part 'add_product_event.dart';
part 'add_product_state.dart';

class AddProductBloc extends Bloc<AddProductEvent, AddProductState> {
  final ProductRemoteDatasource productRemoteDatasource;
  AddProductBloc(
    this.productRemoteDatasource,
  ) : super(const _Initial()) {
    on<_AddProduct>((event, emit) async {
      emit(const _Loading());
      //jika apa product A maka B maka C
      final result = await productRemoteDatasource.addProduct(event.data);
      result.fold(
        (error) => emit(_Error(message: error)),
        (_) => emit(const _Success()),
      );
    });
  }
}
