import 'package:bloc/bloc.dart';
import 'package:flutter_food_delivery_resto_app/data/datasources/statistic_remote_datasource.dart';
import 'package:flutter_food_delivery_resto_app/data/models/response/total_model.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'get_total_today_transaction_event.dart';
part 'get_total_today_transaction_state.dart';
part 'get_total_today_transaction_bloc.freezed.dart';

class GetTotalTodayTransactionBloc
    extends Bloc<GetTotalTodayTransactionEvent, GetTotalTodayTransactionState> {
  final StatisticRemoteDatasource datasource;
  GetTotalTodayTransactionBloc(this.datasource) : super(_Initial()) {
    on<_GetTotalTodayTransaction>((event, emit) async {
      emit(const _Loading());
      final result = await datasource.getTotalTodayTransaction();
      result.fold(
        (error) => emit(_Error(error)),
        (data) => emit(_Success(data)),
      );
    });
  }
}
