part of 'get_total_today_transaction_bloc.dart';

@freezed
class GetTotalTodayTransactionEvent with _$GetTotalTodayTransactionEvent {
  const factory GetTotalTodayTransactionEvent.started() = _Started;
  const factory GetTotalTodayTransactionEvent.getTotalTodayTransaction() = _GetTotalTodayTransaction;
}