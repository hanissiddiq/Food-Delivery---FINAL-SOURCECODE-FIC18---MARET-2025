part of 'get_total_today_transaction_bloc.dart';

@freezed
class GetTotalTodayTransactionState with _$GetTotalTodayTransactionState {
  const factory GetTotalTodayTransactionState.initial() = _Initial;
  const factory GetTotalTodayTransactionState.loading() = _Loading;
  const factory GetTotalTodayTransactionState.success(TotalModel data) = _Success;
  const factory GetTotalTodayTransactionState.error(String error) = _Error;

}
