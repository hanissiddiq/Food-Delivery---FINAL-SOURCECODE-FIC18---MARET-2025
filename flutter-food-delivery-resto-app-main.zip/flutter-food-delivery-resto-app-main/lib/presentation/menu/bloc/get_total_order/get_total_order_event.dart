part of 'get_total_order_bloc.dart';

@freezed
class GetTotalOrderEvent with _$GetTotalOrderEvent {
  const factory GetTotalOrderEvent.started() = _Started;
  const factory GetTotalOrderEvent.getTotalOder() = _GetTotalOrder;
}