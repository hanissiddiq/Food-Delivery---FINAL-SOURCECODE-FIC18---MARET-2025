part of 'get_total_order_bloc.dart';

@freezed
class GetTotalOrderState with _$GetTotalOrderState {
  const factory GetTotalOrderState.initial() = _Initial;
  const factory GetTotalOrderState.loading() = _Loading;
  const factory GetTotalOrderState.success(TotalModel data) = _Success;
  const factory GetTotalOrderState.error(String error) = _Error;
}
