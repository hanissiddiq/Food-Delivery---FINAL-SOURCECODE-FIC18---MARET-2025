part of 'order_history_bloc.dart';

@freezed
class OrderHistoryState with _$OrderHistoryState {
  const factory OrderHistoryState.initial() = _Initial;
  const factory OrderHistoryState.loading() = _Loading;
  const factory OrderHistoryState.loaded(List<OrderHistory> orderHistories) = _Loaded;
  const factory OrderHistoryState.error(String message) = _Error;
}
