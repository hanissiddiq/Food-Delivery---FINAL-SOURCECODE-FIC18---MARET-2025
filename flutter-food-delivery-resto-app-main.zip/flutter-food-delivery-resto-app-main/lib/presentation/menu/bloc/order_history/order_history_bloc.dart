import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import 'package:flutter_food_delivery_resto_app/data/datasources/order_remote_datasource.dart';

import '../../../../data/models/response/order_history_response_model.dart';

part 'order_history_bloc.freezed.dart';
part 'order_history_event.dart';
part 'order_history_state.dart';

class OrderHistoryBloc extends Bloc<OrderHistoryEvent, OrderHistoryState> {
  final OrderRemoteDatasource datasource;
  OrderHistoryBloc(
    this.datasource,
  ) : super(const _Initial()) {
    on<_GetAll>((event, emit) async {
      emit(const _Loading());
      final result = await datasource.getOrder();
      result.fold(
        (l) => emit(_Error(l)),
        (r) => emit(_Loaded(r.data!)),
      );
    });
  }
}
