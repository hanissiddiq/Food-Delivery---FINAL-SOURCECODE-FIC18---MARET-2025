import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_resto_app/data/models/response/order_history_response_model.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/bloc/update_status/update_status_bloc.dart';

import '../../../core/core.dart';
import '../bloc/order_history/order_history_bloc.dart';

class OrderCard extends StatelessWidget {
  final OrderHistory item;
  const OrderCard({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
// context.push(OrderDetailPage(
//         order: [item],
//       )),
      },
      child: Container(
          padding: const EdgeInsets.all(12.0),
          decoration: BoxDecoration(
            color: AppColors.white,
            borderRadius: BorderRadius.circular(24.0),
            boxShadow: [
              BoxShadow(
                offset: const Offset(0, 0),
                blurRadius: 8.0,
                spreadRadius: 0,
                color: AppColors.stroke.withOpacity(0.5),
                blurStyle: BlurStyle.outer,
              )
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.totalPrice!.currencyFormatRp,
                style: const TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SpaceHeight(4.0),
              SizedBox(
                // width: context.deviceWidth - 182.0,
                child: Text(
                  item.shippingAddress ?? '',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12.0,
                    fontWeight: FontWeight.w500,
                    color: AppColors.gray2,
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    // width: context.deviceWidth - 270.0,
                    child: Text(
                      item.paymentMethod ?? '',
                      style: const TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 108.0,
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: InkWell(
                        onTap: () {
                          context.read<UpdateStatusBloc>().add(
                              UpdateStatusEvent.updateStatus(
                                  id: item.id!,
                                  status: item.status == 'processing'
                                      ? 'prepared'
                                      : 'ready_for_delivery'));
                        },
                        child:
                            BlocConsumer<UpdateStatusBloc, UpdateStatusState>(
                          listener: (context, state) {
                            state.maybeWhen(
                              orElse: () {},
                              loaded: () {
                                context
                                    .read<OrderHistoryBloc>()
                                    .add(const OrderHistoryEvent.getAll());
                              },
                            );
                          },
                          builder: (context, state) {
                            return state.maybeWhen(
                              orElse: () {
                                return Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16.0, vertical: 8.0),
                                  decoration: BoxDecoration(
                                    color: AppColors.primary,
                                    borderRadius: BorderRadius.circular(16.0),
                                  ),
                                  child: Text(
                                    item.status ?? '',
                                    style: const TextStyle(
                                      fontSize: 12.0,
                                      color: AppColors.white,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                );
                              },
                              loading: () {
                                return Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16.0, vertical: 8.0),
                                  decoration: BoxDecoration(
                                    color: AppColors.primary,
                                    borderRadius: BorderRadius.circular(16.0),
                                  ),
                                  child: const CircularProgressIndicator(
                                    color: AppColors.white,
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          )),
    );
  }
}
