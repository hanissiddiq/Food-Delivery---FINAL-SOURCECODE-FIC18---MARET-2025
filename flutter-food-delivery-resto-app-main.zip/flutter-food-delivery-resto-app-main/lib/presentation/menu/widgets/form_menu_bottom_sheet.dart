import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_resto_app/data/models/request/product_request_model.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/bloc/add_product/add_product_bloc.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/bloc/get_product/get_product_bloc.dart';
import 'package:image_picker/image_picker.dart';

import '../../../core/core.dart';

class FormMenuBottomSheet extends StatefulWidget {
  // final MenuModel? item;
  const FormMenuBottomSheet({
    super.key,
  });

  @override
  State<FormMenuBottomSheet> createState() => _FormMenuBottomSheetState();
}

class _FormMenuBottomSheetState extends State<FormMenuBottomSheet> {
  late final TextEditingController nameController;
  //description
  late final TextEditingController descriptionController;
  late final TextEditingController priceController;
  late final TextEditingController stockController;

  bool isFavorite = false;
  bool isAvailable = true;
  String previousStock = '';

  XFile? image;

  @override
  void initState() {
    nameController = TextEditingController();
    descriptionController = TextEditingController();
    priceController = TextEditingController();
    stockController = TextEditingController();
    // nameController = TextEditingController(text: widget.item?.name);
    // priceController =
    //     TextEditingController(text: '${widget.item?.price ?? ''}');
    // stockController =
    //     TextEditingController(text: '${widget.item?.stock ?? ''}');
    // imageController = TextEditingController(text: widget.item?.imageUrl);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 24.0, horizontal: 18.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomTextField(
            controller: nameController,
            label: 'Nama Menu',
            textInputAction: TextInputAction.next,
          ),
          const SpaceHeight(18.0),
          CustomTextField(
            controller: descriptionController,
            label: 'Deskripsi Menu',
            textInputAction: TextInputAction.next,
          ),
          const SpaceHeight(18.0),
          CustomTextField(
            controller: priceController,
            label: 'Harga ',
            keyboardType: TextInputType.number,
            textInputAction: TextInputAction.next,
            inputFormatter: [FilteringTextInputFormatter.digitsOnly],
          ),
          const SpaceHeight(18.0),
          CustomTextField(
            controller: stockController,
            label: 'Stok',
            keyboardType: TextInputType.number,
            textInputAction: TextInputAction.next,
            inputFormatter: [FilteringTextInputFormatter.digitsOnly],
            readOnly: !isAvailable,
          ),
          const SpaceHeight(18.0),
          CustomImagePicker(
            label: 'Foto Menu',
            // imageUrl: widget.item?.imageUrl,
            onChanged: (imagePath) {
              image = imagePath;
            },
          ),
          const SpaceHeight(18.0),
          Row(
            children: [
              Checkbox(
                value: isFavorite,
                onChanged: (value) {
                  setState(() {
                    isFavorite = value!;
                  });
                },
              ),
              const Text('Favorit'),
              const SpaceWidth(18.0),
              Checkbox(
                value: isAvailable,
                onChanged: (value) {
                  setState(() {
                    isAvailable = value!;
                    if (!isAvailable) {
                      previousStock = stockController.text;
                      stockController.text = '0';
                    } else {
                      stockController.text = previousStock;
                    }
                  });
                },
              ),
              const Text('Tersedia'),
            ],
          ),
          const SpaceHeight(35.0),
          BlocConsumer<AddProductBloc, AddProductState>(
            listener: (context, state) {
              state.maybeWhen(
                orElse: () {},
                success: () {
                  context.showDialogSuccess(
                      'Success', 'Menu berhasil ditambahkan');
                  Navigator.pop(context);
                  Navigator.pop(context);
                  context
                      .read<GetProductBloc>()
                      .add(const GetProductEvent.getProducts());
                },
                error: (message) {
                  context.showDialogError('Failed', message);
                },
              );
            },
            builder: (context, state) {
              return state.maybeWhen(
                orElse: () {
                  return Button.filled(
                    onPressed: () {
                      if (image == null) {
                        context.showImageRequiredDialog(
                          message: 'Gambar Product Masih Kosong!',
                          iconPath: Assets.icons.alert.imageBlank.path,
                        );
                      } else if (nameController.text.isEmpty ||
                          priceController.text.isEmpty ||
                          stockController.text.isEmpty) {
                        context.showDialogError(
                            'Failed', 'Terdapat inputan yang masih kosong');
                      } else {
                        final data = ProductRequestModel(
                          name: nameController.text,
                          description: descriptionController.text,
                          price: priceController.text.toInt,
                          stock: stockController.text.toInt,
                          isFavorite: isFavorite ? 1 : 0,
                          isAvailable: isAvailable ? 1 : 0,
                          image: image!,
                        );

                        context
                            .read<AddProductBloc>()
                            .add(AddProductEvent.addProduct(data: data));
                      }
                    },
                    label: 'Simpan',
                  );
                },
                loading: () {
                  return const Center(child: CircularProgressIndicator());
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
