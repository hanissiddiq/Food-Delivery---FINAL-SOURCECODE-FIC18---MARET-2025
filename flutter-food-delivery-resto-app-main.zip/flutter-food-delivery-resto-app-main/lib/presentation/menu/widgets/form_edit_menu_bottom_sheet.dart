import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/bloc/update_product/update_product_bloc.dart';
import 'package:image_picker/image_picker.dart';

import 'package:flutter_food_delivery_resto_app/data/models/request/product_request_model.dart';
import 'package:flutter_food_delivery_resto_app/data/models/response/product_response_modeld.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/bloc/get_product/get_product_bloc.dart';

import '../../../core/core.dart';

class FormEditMenuBottomSheet extends StatefulWidget {
  final Product item;
  const FormEditMenuBottomSheet({
    super.key,
    required this.item,
  });

  @override
  State<FormEditMenuBottomSheet> createState() => _FormMenuBottomSheetState();
}

class _FormMenuBottomSheetState extends State<FormEditMenuBottomSheet> {
  late final TextEditingController nameController;
  //description
  late final TextEditingController descriptionController;
  late final TextEditingController priceController;
  late final TextEditingController stockController;

  bool isFavorite = false;
  bool isAvailable = true;

  XFile? image;

  @override
  void initState() {
    nameController = TextEditingController(text: widget.item.name);
    descriptionController =
        TextEditingController(text: widget.item.description);
    priceController = TextEditingController(text: widget.item.price.toString());
    stockController = TextEditingController(text: widget.item.stock.toString());
    isAvailable = widget.item.isAvailable! == '1';
    isFavorite = widget.item.isFavorite! == '1';
    // nameController = TextEditingController(text: widget.item?.name);
    // priceController =
    //     TextEditingController(text: '${widget.item?.price ?? ''}');
    // stockController =
    //     TextEditingController(text: '${widget.item?.stock ?? ''}');
    // imageController = TextEditingController(text: widget.item?.imageUrl);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 24.0, horizontal: 18.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomTextField(
            controller: nameController,
            label: 'Nama Menu',
            textInputAction: TextInputAction.next,
          ),
          const SpaceHeight(18.0),
          CustomTextField(
            controller: descriptionController,
            label: 'Deskripsi Menu',
            textInputAction: TextInputAction.next,
          ),
          const SpaceHeight(18.0),
          CustomTextField(
            controller: priceController,
            label: 'Harga ',
            keyboardType: TextInputType.number,
            textInputAction: TextInputAction.next,
          ),
          const SpaceHeight(18.0),
          CustomTextField(
            controller: stockController,
            label: 'Stok',
            keyboardType: TextInputType.number,
            textInputAction: TextInputAction.next,
          ),
          const SpaceHeight(18.0),
          // CustomImagePicker(
          //   label: 'Foto Menu',
          //   // imageUrl: widget.item?.imageUrl,
          //   onChanged: (imagePath) {
          //     image = imagePath;
          //   },
          // ),
          // const SpaceHeight(18.0),
          Row(
            children: [
              Checkbox(
                value: isFavorite,
                onChanged: (value) {
                  setState(() {
                    isFavorite = value!;
                  });
                },
              ),
              const Text('Favorit'),
              const SpaceWidth(18.0),
              Checkbox(
                value: isAvailable,
                onChanged: (value) {
                  setState(() {
                    isAvailable = value!;
                  });
                },
              ),
              const Text('Tersedia'),
            ],
          ),
          const SpaceHeight(35.0),
          BlocConsumer<UpdateProductBloc, UpdateProductState>(
            listener: (context, state) {
              state.maybeWhen(
                orElse: () {},
                success: () {
                  context.showDialogSuccess(
                      'Success', 'Menu berhasil ditambahkan');
                  Navigator.pop(context);
                  Navigator.pop(context);
                  context
                      .read<GetProductBloc>()
                      .add(const GetProductEvent.getProducts());
                },
                error: (message) {
                  context.showDialogError('Failed', message);
                },
              );
            },
            builder: (context, state) {
              return state.maybeWhen(
                orElse: () {
                  return Button.filled(
                    onPressed: () {
                      if (nameController.text.isEmpty ||
                          priceController.text.isEmpty ||
                          stockController.text.isEmpty) {
                        context.showDialogError(
                            'Failed', 'Terdapat inputan yang masih kosong');
                      } else {
                        final data = ProductRequestModel(
                          name: nameController.text,
                          description: descriptionController.text,
                          price: priceController.text.toInt,
                          stock: stockController.text.toInt,
                          isFavorite: isFavorite ? 1 : 0,
                          isAvailable: isAvailable ? 1 : 0,
                          // image: image!,
                        );

                        context.read<UpdateProductBloc>().add(
                            UpdateProductEvent.updateProduct(
                                data: data, id: widget.item.id!));
                      }
                    },
                    label: 'Simpan',
                  );
                },
                loading: () {
                  return const Center(child: CircularProgressIndicator());
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
