import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_resto_app/core/constants/variables.dart';
import 'package:flutter_food_delivery_resto_app/data/models/response/product_response_modeld.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/bloc/delete_product/delete_product_bloc.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/bloc/get_total_product/get_total_product_bloc.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/widgets/form_edit_menu_bottom_sheet.dart';

import '../../../core/core.dart';
import '../bloc/get_product/get_product_bloc.dart';

class MenuCard extends StatelessWidget {
  final Product item;
  const MenuCard({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16.0),
        boxShadow: [
          BoxShadow(
            offset: const Offset(0, 0),
            blurRadius: 8.0,
            spreadRadius: 0,
            color: AppColors.black.withOpacity(0.2),
            blurStyle: BlurStyle.outer,
          )
        ],
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(16.0),
            child: CachedNetworkImage(
              imageUrl: '${Variables.baseUrl}/uploads/products/${item.image!}',
              fit: BoxFit.cover,
              width: 90.0,
              height: 90.0,
              placeholder: (context, url) =>
                  const Center(child: CircularProgressIndicator()),
            ),
          ),
          const SpaceWidth(28.0),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.name ?? '',
                style: const TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SpaceHeight(4.0),
              Text(
                'Stok: ${item.stock}',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 12.0,
                  fontWeight: FontWeight.w500,
                  color: AppColors.gray2,
                ),
              ),
              Row(
                children: [
                  SizedBox(
                    width: context.deviceWidth - 285.0,
                    child: Text(
                      item.price!.toInt.currencyFormatRp,
                      style: const TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (context) => AlertDialog(
                          content: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 20.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Text(
                                  'Hapus Menu Ini ?',
                                  style: TextStyle(
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SpaceHeight(16.0),
                                const Text(
                                  'Apakah Anda yakin ingin menghapus menu ini?',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: AppColors.gray1,
                                  ),
                                ),
                                const SpaceHeight(30.0),
                                Row(
                                  children: [
                                    Flexible(
                                      child: Button.filled(
                                        onPressed: () => context.pop(),
                                        label: 'Batal',
                                        color: AppColors.red,
                                      ),
                                    ),
                                    const SpaceWidth(16.0),
                                    Flexible(
                                      child: Button.filled(
                                        onPressed: () {
                                          context.read<DeleteProductBloc>().add(
                                                DeleteProductEvent
                                                    .deleteProduct(
                                                        id: item.id!),
                                              );
                                          context.pop();
                                          context.read<GetProductBloc>().add(
                                                const GetProductEvent
                                                    .getProducts(),
                                              );
                                          context
                                              .read<GetTotalProductBloc>()
                                              .add(GetTotalProductEvent
                                                  .getTotalProduct());
                                          context.showDialogSuccess(
                                              'Sukses Hapus Menu',
                                              'Menu kamu telah dihapus di daftar menu, dan akan dihilangkan di halaman menu pembeli');
                                        },
                                        label: 'Hapus',
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                    icon: Assets.icons.delete.svg(),
                  ),
                  IconButton(
                    onPressed: () {
                      showModalBottomSheet(
                        context: context,
                        isScrollControlled: true,
                        useSafeArea: true,
                        builder: (context) => FormEditMenuBottomSheet(
                          item: item,
                        ),
                      );
                    },
                    icon: Assets.icons.edit.svg(),
                  ),
                ],
              ),
            ],
          )
        ],
      ),
    );
  }
}
