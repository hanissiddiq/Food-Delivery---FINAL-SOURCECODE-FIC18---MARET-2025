import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_resto_app/core/core.dart';
import 'package:flutter_food_delivery_resto_app/data/datasources/auth_local_datasource.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/bloc/get_income/get_income_bloc.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/bloc/get_total_order/get_total_order_bloc.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/bloc/get_total_product/get_total_product_bloc.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/bloc/get_total_today_transaction/get_total_today_transaction_bloc.dart';

import '../widgets/home_menu_tile.dart';

class HomeRestoPage extends StatefulWidget {
  const HomeRestoPage({super.key});

  @override
  State<HomeRestoPage> createState() => _HomeRestoPageState();
}

class _HomeRestoPageState extends State<HomeRestoPage> {
  String restaurantName = 'Resto App';

  @override
  void initState() {
    super.initState();
    context
        .read<GetTotalProductBloc>()
        .add(GetTotalProductEvent.getTotalProduct());
    context.read<GetTotalOrderBloc>().add(GetTotalOrderEvent.getTotalOder());
    context
        .read<GetTotalTodayTransactionBloc>()
        .add(GetTotalTodayTransactionEvent.getTotalTodayTransaction());
    context.read<GetIncomeBloc>().add(GetIncomeEvent.getIncome());
    AuthLocalDatasource().getAuthData().then((value) {
      setState(() {
        restaurantName = value.data!.user!.restaurantName!;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: ListView(
          padding: const EdgeInsets.symmetric(
            horizontal: 24.0,
            vertical: 50.0,
          ),
          children: [
            Container(
              padding: const EdgeInsets.all(24.0),
              decoration: BoxDecoration(
                border: Border.all(color: AppColors.stroke),
                borderRadius: BorderRadius.circular(16.0),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Statistik Resto ',
                    style: TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    '$restaurantName ',
                    style: TextStyle(
                        fontSize: 22.0,
                        fontWeight: FontWeight.w700,
                        color: AppColors.primary),
                  ),
                  const SpaceHeight(32.0),
                  Row(
                    children: [
                      Expanded(
                        child:
                            BlocBuilder<GetTotalOrderBloc, GetTotalOrderState>(
                          builder: (context, state) {
                            return state.maybeWhen(
                              success: (data) {
                                return HomeMenuTile(
                                  label: 'Jumlah Pesanan',
                                  info: '${data.data} Pesanan',
                                  iconSvgPath:
                                      Assets.icons.homeResto.jumlahPesanan.path,
                                  color: AppColors.homeGreen,
                                  onPressed: () {},
                                );
                              },
                              orElse: () => HomeMenuTile(
                                isUsingIcon: false,
                                label: '',
                                info: '',
                                iconSvgPath: Assets.icons.homeResto.menu.path,
                                color: Colors.grey.withOpacity(0.5),
                                onPressed: () {},
                              ),
                            );
                          },
                        ),
                      ),
                      const SpaceWidth(16.0),
                      Expanded(
                        child: BlocBuilder<GetTotalProductBloc,
                            GetTotalProductState>(
                          builder: (context, state) {
                            log('State: $state');
                            return state.maybeWhen(
                              success: (data) {
                                return HomeMenuTile(
                                  label: 'Menu',
                                  info: '${data.data} Produk',
                                  iconSvgPath: Assets.icons.homeResto.menu.path,
                                  color: AppColors.homeBlue,
                                  onPressed: () {},
                                );
                              },
                              orElse: () => HomeMenuTile(
                                isUsingIcon: false,
                                label: '',
                                info: '',
                                iconSvgPath: Assets.icons.homeResto.menu.path,
                                color: Colors.grey.withOpacity(0.5),
                                onPressed: () {},
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                  const SpaceHeight(16.0),
                  Row(
                    children: [
                      Expanded(
                        child: BlocBuilder<GetTotalTodayTransactionBloc,
                            GetTotalTodayTransactionState>(
                          builder: (context, state) {
                            return state.maybeWhen(
                              success: (data) {
                                return HomeMenuTile(
                                  label: 'Transaksi Hari Ini',
                                  info: '${data.data} Transaksi',
                                  iconSvgPath: Assets
                                      .icons.homeResto.transaksiHariIni.path,
                                  color: AppColors.homeYellow,
                                  onPressed: () {},
                                );
                              },
                              orElse: () => HomeMenuTile(
                                isUsingIcon: false,
                                label: '',
                                info: '',
                                iconSvgPath: Assets.icons.homeResto.menu.path,
                                color: Colors.grey.withOpacity(0.5),
                                onPressed: () {},
                              ),
                            );
                          },
                        ),
                      ),
                      const SpaceWidth(16.0),
                      Expanded(
                        child: BlocBuilder<GetIncomeBloc, GetIncomeState>(
                          builder: (context, state) {
                            log("Income State: $state");
                            return state.maybeWhen(
                              success: (data) {
                                return HomeMenuTile(
                                  label: 'Pemasukan',
                                  info: '${data.data!.currencyFormatRp}',
                                  iconSvgPath:
                                      Assets.icons.homeResto.pemasukan.path,
                                  color: AppColors.homePurple,
                                  onPressed: () {},
                                );
                              },
                              orElse: () => HomeMenuTile(
                                isUsingIcon: false,
                                label: '',
                                info: '',
                                iconSvgPath: Assets.icons.homeResto.menu.path,
                                color: Colors.grey.withOpacity(0.5),
                                onPressed: () {},
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
