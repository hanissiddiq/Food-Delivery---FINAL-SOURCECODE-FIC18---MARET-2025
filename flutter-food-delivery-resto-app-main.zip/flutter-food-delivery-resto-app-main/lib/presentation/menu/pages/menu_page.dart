import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/bloc/get_product/get_product_bloc.dart';

import '../../../core/core.dart';
import '../widgets/form_menu_bottom_sheet.dart';
import '../widgets/menu_card.dart';

class MenuPage extends StatefulWidget {
  const MenuPage({super.key});

  @override
  State<MenuPage> createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {
  @override
  void initState() {
    super.initState();
    context.read<GetProductBloc>().add(const GetProductEvent.getProducts());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Menu'),
        actions: [
          IconButton(
            onPressed: () {
              showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                useSafeArea: true,
                builder: (context) => const FormMenuBottomSheet(),
              );
            },
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: BlocBuilder<GetProductBloc, GetProductState>(
        builder: (context, state) {
          return state.maybeWhen(orElse: () {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }, loaded: (menus) {
            if (menus.isEmpty) {
              return const Center(
                child: Text('Data tidak ditemukan'),
              );
            }
            return ListView.separated(
              padding: const EdgeInsets.all(16.0),
              itemCount: menus.length,
              separatorBuilder: (context, index) => const SpaceHeight(16.0),
              itemBuilder: (context, index) => MenuCard(
                item: menus[index],
              ),
            );
          }, error: (error) {
            return Center(
              child: Text(error),
            );
          });
          // return ListView.separated(
          //   padding: const EdgeInsets.all(20.0),
          //   itemCount: menus.length,
          //   separatorBuilder: (context, index) => const SpaceHeight(12.0),
          //   itemBuilder: (context, index) => MenuCard(
          //     item: menus[index],
          //   ),
          // );
        },
      ),
    );
  }
}
