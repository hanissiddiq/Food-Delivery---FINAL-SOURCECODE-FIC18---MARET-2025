import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/bloc/order_history/order_history_bloc.dart';

import '../../../core/core.dart';
import '../widgets/order_card.dart';

class OrderPage extends StatefulWidget {
  const OrderPage({super.key});

  @override
  State<OrderPage> createState() => _OrderPageState();
}

class _OrderPageState extends State<OrderPage> {
  @override
  void initState() {
    context.read<OrderHistoryBloc>().add(const OrderHistoryEvent.getAll());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Pesanan'),
        actions: [
          IconButton(
            onPressed: () {
              context
                  .read<OrderHistoryBloc>()
                  .add(const OrderHistoryEvent.getAll());
            },
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: BlocBuilder<OrderHistoryBloc, OrderHistoryState>(
        builder: (context, state) {
          return state.maybeWhen(
            orElse: () {
              return const Center(
                child: CircularProgressIndicator(),
              );
            },
            loaded: (orders) {
              if (orders.isEmpty) {
                return const Center(
                  child: Text('Data tidak ditemukan'),
                );
              }
              return ListView.separated(
                padding: const EdgeInsets.all(20.0),
                itemCount: orders.length,
                separatorBuilder: (context, index) => const SpaceHeight(18.0),
                itemBuilder: (context, index) => OrderCard(
                  item: orders[index],
                ),
              );
            },
            error: (error) {
              return Center(
                child: Text(error),
              );
            },
          );
        },
      ),
    );
  }
}
