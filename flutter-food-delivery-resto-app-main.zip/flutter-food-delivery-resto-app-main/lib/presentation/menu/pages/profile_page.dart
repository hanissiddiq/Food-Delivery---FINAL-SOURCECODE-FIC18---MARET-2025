// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_food_delivery_resto_app/core/core.dart';
import 'package:flutter_food_delivery_resto_app/data/datasources/auth_local_datasource.dart';
import 'package:flutter_food_delivery_resto_app/presentation/auth/bloc/logout/logout_bloc.dart';
import 'package:flutter_food_delivery_resto_app/presentation/auth/pages/login_page.dart';
import 'package:flutter_food_delivery_resto_app/presentation/menu/widgets/profile_header.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          const ProfileHeader(),
          const SpaceHeight(10.0),
          const Text(
            'Saiful Bahri',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 22.0,
              fontWeight: FontWeight.w600,
              color: AppColors.primary,
            ),
          ),
          const Text(
            'bahri@jagoflutter.id | 0812-3456-7891',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: AppColors.primary,
            ),
          ),
          const SpaceHeight(30.0),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Card(
              color: AppColors.white,
              child: Column(
                children: [
                  ListTile(
                    leading: Assets.icons.myAccountCircle.svg(),
                    title: const Text('My Account'),
                    subtitle: const Text('Make changes to your account'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {},
                  ),
                  ListTile(
                    leading: Assets.icons.logoutCircle.svg(),
                    title: const Text('Log out'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () async {
                      context
                          .read<LogoutBloc>()
                          .add(const LogoutEvent.logout());
                      await AuthLocalDatasource().removeAuthData();
                      context.pushReplacement(const LoginPage());
                    },
                  ),
                  ListTile(
                    leading: Assets.icons.helpAndSupportCircle.svg(),
                    title: const Text('Help & Support'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {},
                  ),
                  ListTile(
                    leading: Assets.icons.aboutAppCircle.svg(),
                    title: const Text('About App'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () {},
                  ),
                ],
              ),
            ),
          ),
          const SpaceHeight(30.0),
        ],
      ),
    );
  }
}
