import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'testing_event.dart';
part 'testing_state.dart';
part 'testing_bloc.freezed.dart';

class TestingBloc extends Bloc<TestingEvent, TestingState> {
  TestingBloc() : super(const _Initial()) {
    on<TestingEvent>((event, emit) {
    });
  }
}
