package com.jagoflutter.flutter_food_delivery_resto_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
